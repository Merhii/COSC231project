﻿CREATE PROCEDURE UpdatePolicy
@Policy_Number int,
@Plate_number nvarchar(15),
@Active BIT
AS
UPDATE Vehicle_Policy
SET Plate_number=@Plate_number,
Active=@Active
WHERE Policy_Number=@Policy_Number
