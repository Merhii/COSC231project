﻿CREATE TABLE Employee (
  E_ID INT IDENTITY(1000,1),
  Name NVARCHAR(25),
  Email NVARCHAR(55),
  Password NVARCHAR(8),
  PRIMARY KEY (E_ID)
);

CREATE TABLE Client (
  C_ID INT IDENTITY(1,1),
  E_ID INT,
  SSN INT,
  Name NVARCHAR(25),
  Age INT,
  City NVARCHAR(25),
  Street NVARCHAR(25),
  Nationality NVARCHAR(25),
  Phone_Number INT,
  License_Number NVARCHAR(25),
  Email NVARCHAR(35),
  PRIMARY KEY (C_ID),
  CONSTRAINT FK_Client_Employee_EID FOREIGN KEY (E_ID) REFERENCES Employee(E_ID)
);

CREATE TABLE Vehicle_Policy (
  Policy_Number INT IDENTITY(1000,1),
  C_ID INT,
  Model NVARCHAR(30),
  Price REAL,
  Coverage REAL,
  Plate_number NVARCHAR(15),
  Model_Year INT,
  Brand NVARCHAR(15),
  Color NVARCHAR(15),
  Start_Date DATE,
  Expiry_Date DATE,
  Active BIT,
  Paid_From_Coverage INT,
  PRIMARY KEY (Policy_Number,Plate_number),
  CONSTRAINT FK_Vehicle_Policy_C_ID FOREIGN KEY (C_ID) REFERENCES Client(C_ID),
);

CREATE TABLE Payment_Details (
  P_ID INT IDENTITY(1000,1),
  C_ID INT,
  Payment_Date DATE,
  Amount REAL,
  Payment_Method NVARCHAR(25),
  Bank_Name NVARCHAR(25),
  Check_Number INT,
  Policy_Number INT,
  PRIMARY KEY (P_ID),
  CONSTRAINT FK_Payment_Details_Client_CID FOREIGN KEY (C_ID) REFERENCES Client(C_ID)
);

CREATE TABLE Accident_Specialist (
  AS_ID INT IDENTITY(1000,1),
  Name NVARCHAR(25),
  Phone_Number INT,
  Email NVARCHAR(25),
  Address NVARCHAR(25),
  PRIMARY KEY (AS_ID)
);

CREATE TABLE Accident (
  A_ID INT IDENTITY(1,1),
  C_ID INT,
  AS_ID INT,
  Plate_Number NVARCHAR(15),
  Policy_Number INT,
  Place NVARCHAR(25),
  Date_Of_Acc DATE,
  Approval BIT,
  Expenses REAL,
  PRIMARY KEY (A_ID),

  CONSTRAINT FK_Accident_Client_CID FOREIGN KEY (C_ID) REFERENCES Client(C_ID),

  CONSTRAINT FK_Accident_Vehicle_Policy_PlateNumber
  FOREIGN KEY (Policy_Number, Plate_Number) 
  REFERENCES Vehicle_Policy(Policy_Number, Plate_Number),

  CONSTRAINT FK_Accident_Specialist_ASID FOREIGN KEY (AS_ID) REFERENCES Accident_Specialist(AS_ID)
);
