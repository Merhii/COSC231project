﻿namespace Project_take1
{
    partial class UserControlEditAs
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UserControlEditAs));
            this.txt_Phone = new System.Windows.Forms.TextBox();
            this.labelpass = new System.Windows.Forms.Label();
            this.txt_Namee = new System.Windows.Forms.TextBox();
            this.txt_emaile = new System.Windows.Forms.TextBox();
            this.txt_IDe = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.labelID = new System.Windows.Forms.Label();
            this.rd_Remove = new System.Windows.Forms.RadioButton();
            this.rd_Add = new System.Windows.Forms.RadioButton();
            this.btn_Removee = new System.Windows.Forms.Button();
            this.btn_Adde = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txt_Address = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txt_Phone
            // 
            this.txt_Phone.Location = new System.Drawing.Point(129, 187);
            this.txt_Phone.Margin = new System.Windows.Forms.Padding(2);
            this.txt_Phone.Name = "txt_Phone";
            this.txt_Phone.Size = new System.Drawing.Size(135, 20);
            this.txt_Phone.TabIndex = 56;
            // 
            // labelpass
            // 
            this.labelpass.AutoSize = true;
            this.labelpass.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelpass.Location = new System.Drawing.Point(14, 228);
            this.labelpass.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelpass.Name = "labelpass";
            this.labelpass.Size = new System.Drawing.Size(53, 17);
            this.labelpass.TabIndex = 55;
            this.labelpass.Text = "E-mail";
            // 
            // txt_Namee
            // 
            this.txt_Namee.Location = new System.Drawing.Point(129, 148);
            this.txt_Namee.Margin = new System.Windows.Forms.Padding(2);
            this.txt_Namee.Name = "txt_Namee";
            this.txt_Namee.Size = new System.Drawing.Size(135, 20);
            this.txt_Namee.TabIndex = 52;
            this.txt_Namee.TextChanged += new System.EventHandler(this.txt_Namee_TextChanged);
            // 
            // txt_emaile
            // 
            this.txt_emaile.Location = new System.Drawing.Point(129, 228);
            this.txt_emaile.Margin = new System.Windows.Forms.Padding(2);
            this.txt_emaile.Name = "txt_emaile";
            this.txt_emaile.Size = new System.Drawing.Size(135, 20);
            this.txt_emaile.TabIndex = 51;
            // 
            // txt_IDe
            // 
            this.txt_IDe.Location = new System.Drawing.Point(129, 187);
            this.txt_IDe.Margin = new System.Windows.Forms.Padding(2);
            this.txt_IDe.Name = "txt_IDe";
            this.txt_IDe.Size = new System.Drawing.Size(135, 20);
            this.txt_IDe.TabIndex = 50;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(14, 187);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(115, 17);
            this.label3.TabIndex = 48;
            this.label3.Text = "Phone Number";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(14, 151);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 17);
            this.label2.TabIndex = 47;
            this.label2.Text = "Name";
            // 
            // labelID
            // 
            this.labelID.AutoSize = true;
            this.labelID.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelID.Location = new System.Drawing.Point(19, 187);
            this.labelID.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelID.Name = "labelID";
            this.labelID.Size = new System.Drawing.Size(23, 17);
            this.labelID.TabIndex = 46;
            this.labelID.Text = "ID";
            // 
            // rd_Remove
            // 
            this.rd_Remove.AutoSize = true;
            this.rd_Remove.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rd_Remove.Location = new System.Drawing.Point(5, 104);
            this.rd_Remove.Margin = new System.Windows.Forms.Padding(2);
            this.rd_Remove.Name = "rd_Remove";
            this.rd_Remove.Size = new System.Drawing.Size(159, 21);
            this.rd_Remove.TabIndex = 45;
            this.rd_Remove.TabStop = true;
            this.rd_Remove.Text = "Remove Specialist";
            this.rd_Remove.UseVisualStyleBackColor = true;
            this.rd_Remove.CheckedChanged += new System.EventHandler(this.rd_Remove_CheckedChanged);
            // 
            // rd_Add
            // 
            this.rd_Add.AutoSize = true;
            this.rd_Add.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rd_Add.Location = new System.Drawing.Point(6, 65);
            this.rd_Add.Margin = new System.Windows.Forms.Padding(2);
            this.rd_Add.Name = "rd_Add";
            this.rd_Add.Size = new System.Drawing.Size(129, 21);
            this.rd_Add.TabIndex = 44;
            this.rd_Add.TabStop = true;
            this.rd_Add.Text = "Add Specialist";
            this.rd_Add.UseVisualStyleBackColor = true;
            this.rd_Add.CheckedChanged += new System.EventHandler(this.rd_Add_CheckedChanged);
            // 
            // btn_Removee
            // 
            this.btn_Removee.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.btn_Removee.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Removee.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Removee.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_Removee.Location = new System.Drawing.Point(387, 294);
            this.btn_Removee.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Removee.Name = "btn_Removee";
            this.btn_Removee.Size = new System.Drawing.Size(151, 36);
            this.btn_Removee.TabIndex = 43;
            this.btn_Removee.Text = "Remove ";
            this.btn_Removee.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.btn_Removee.UseVisualStyleBackColor = false;
            this.btn_Removee.Click += new System.EventHandler(this.btn_Removee_Click);
            // 
            // btn_Adde
            // 
            this.btn_Adde.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.btn_Adde.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Adde.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Adde.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_Adde.Location = new System.Drawing.Point(387, 294);
            this.btn_Adde.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Adde.Name = "btn_Adde";
            this.btn_Adde.Size = new System.Drawing.Size(151, 36);
            this.btn_Adde.TabIndex = 42;
            this.btn_Adde.Text = "Add ";
            this.btn_Adde.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.btn_Adde.UseVisualStyleBackColor = false;
            this.btn_Adde.Click += new System.EventHandler(this.btn_Adde_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LavenderBlush;
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel1.Location = new System.Drawing.Point(292, 37);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(312, 208);
            this.panel1.TabIndex = 57;
            // 
            // txt_Address
            // 
            this.txt_Address.Location = new System.Drawing.Point(129, 269);
            this.txt_Address.Margin = new System.Windows.Forms.Padding(2);
            this.txt_Address.Name = "txt_Address";
            this.txt_Address.Size = new System.Drawing.Size(135, 20);
            this.txt_Address.TabIndex = 59;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(15, 270);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 17);
            this.label1.TabIndex = 58;
            this.label1.Text = "Address";
            // 
            // UserControlEditAs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LavenderBlush;
            this.Controls.Add(this.txt_Address);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.txt_Phone);
            this.Controls.Add(this.labelpass);
            this.Controls.Add(this.txt_Namee);
            this.Controls.Add(this.txt_emaile);
            this.Controls.Add(this.txt_IDe);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.labelID);
            this.Controls.Add(this.rd_Remove);
            this.Controls.Add(this.rd_Add);
            this.Controls.Add(this.btn_Removee);
            this.Controls.Add(this.btn_Adde);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "UserControlEditAs";
            this.Size = new System.Drawing.Size(610, 386);
            this.Load += new System.EventHandler(this.UserControlEditAs_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txt_Phone;
        private System.Windows.Forms.Label labelpass;
        private System.Windows.Forms.TextBox txt_Namee;
        private System.Windows.Forms.TextBox txt_emaile;
        private System.Windows.Forms.TextBox txt_IDe;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label labelID;
        private System.Windows.Forms.RadioButton rd_Remove;
        private System.Windows.Forms.RadioButton rd_Add;
        private System.Windows.Forms.Button btn_Removee;
        private System.Windows.Forms.Button btn_Adde;
        private System.Windows.Forms.TextBox txt_Address;
        private System.Windows.Forms.Label label1;
    }
}
