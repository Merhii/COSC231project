﻿namespace Project_take1
{
    partial class addPolicy
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(addPolicy));
            this.btn_addPolicy = new System.Windows.Forms.Button();
            this.txt_Model = new System.Windows.Forms.TextBox();
            this.lbl_model = new System.Windows.Forms.Label();
            this.database1DataSet = new Project_take1.Database1DataSet();
            this.database1DataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.grid_pview = new System.Windows.Forms.DataGridView();
            this.btn_View = new System.Windows.Forms.Button();
            this.txt_CID = new System.Windows.Forms.TextBox();
            this.txt_Price = new System.Windows.Forms.TextBox();
            this.txt_Coverage = new System.Windows.Forms.TextBox();
            this.txt_PlateNumber = new System.Windows.Forms.TextBox();
            this.txt_ModelYear = new System.Windows.Forms.TextBox();
            this.txt_Brand = new System.Windows.Forms.TextBox();
            this.lbl_CID = new System.Windows.Forms.Label();
            this.lbl__Price = new System.Windows.Forms.Label();
            this.lbl_Coverage = new System.Windows.Forms.Label();
            this.lbl_PlateNumber = new System.Windows.Forms.Label();
            this.lbl_ModelYear = new System.Windows.Forms.Label();
            this.lbl_Brand = new System.Windows.Forms.Label();
            this.lbl_color = new System.Windows.Forms.Label();
            this.comboboxcolor = new System.Windows.Forms.ComboBox();
            this.panel1 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.database1DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.database1DataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grid_pview)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_addPolicy
            // 
            this.btn_addPolicy.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.btn_addPolicy.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_addPolicy.ForeColor = System.Drawing.Color.White;
            this.btn_addPolicy.Location = new System.Drawing.Point(940, 191);
            this.btn_addPolicy.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_addPolicy.Name = "btn_addPolicy";
            this.btn_addPolicy.Size = new System.Drawing.Size(147, 69);
            this.btn_addPolicy.TabIndex = 0;
            this.btn_addPolicy.Text = "ADD POLICY";
            this.btn_addPolicy.UseVisualStyleBackColor = false;
            this.btn_addPolicy.Click += new System.EventHandler(this.btn_addPolicy_Click);
            // 
            // txt_Model
            // 
            this.txt_Model.Location = new System.Drawing.Point(237, 62);
            this.txt_Model.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_Model.Name = "txt_Model";
            this.txt_Model.Size = new System.Drawing.Size(148, 26);
            this.txt_Model.TabIndex = 3;
            this.txt_Model.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // lbl_model
            // 
            this.lbl_model.AutoSize = true;
            this.lbl_model.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_model.Location = new System.Drawing.Point(243, 31);
            this.lbl_model.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_model.Name = "lbl_model";
            this.lbl_model.Size = new System.Drawing.Size(71, 25);
            this.lbl_model.TabIndex = 10;
            this.lbl_model.Text = "Model";
            this.lbl_model.Click += new System.EventHandler(this.txt_model_Click);
            // 
            // database1DataSet
            // 
            this.database1DataSet.DataSetName = "Database1DataSet";
            this.database1DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // database1DataSetBindingSource
            // 
            this.database1DataSetBindingSource.DataSource = this.database1DataSet;
            this.database1DataSetBindingSource.Position = 0;
            // 
            // grid_pview
            // 
            this.grid_pview.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.grid_pview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grid_pview.Location = new System.Drawing.Point(36, 228);
            this.grid_pview.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.grid_pview.Name = "grid_pview";
            this.grid_pview.RowHeadersWidth = 51;
            this.grid_pview.Size = new System.Drawing.Size(675, 357);
            this.grid_pview.TabIndex = 13;
            this.grid_pview.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.grid_pview_CellContentClick);
            // 
            // btn_View
            // 
            this.btn_View.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.btn_View.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_View.ForeColor = System.Drawing.Color.White;
            this.btn_View.Location = new System.Drawing.Point(870, 503);
            this.btn_View.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_View.Name = "btn_View";
            this.btn_View.Size = new System.Drawing.Size(134, 62);
            this.btn_View.TabIndex = 14;
            this.btn_View.Text = "VIEW";
            this.btn_View.UseVisualStyleBackColor = false;
            this.btn_View.Click += new System.EventHandler(this.btn_View_Click);
            // 
            // txt_CID
            // 
            this.txt_CID.Location = new System.Drawing.Point(60, 62);
            this.txt_CID.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_CID.Multiline = true;
            this.txt_CID.Name = "txt_CID";
            this.txt_CID.Size = new System.Drawing.Size(148, 29);
            this.txt_CID.TabIndex = 15;
            // 
            // txt_Price
            // 
            this.txt_Price.Location = new System.Drawing.Point(436, 62);
            this.txt_Price.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_Price.Name = "txt_Price";
            this.txt_Price.Size = new System.Drawing.Size(148, 26);
            this.txt_Price.TabIndex = 16;
            // 
            // txt_Coverage
            // 
            this.txt_Coverage.Location = new System.Drawing.Point(616, 62);
            this.txt_Coverage.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_Coverage.Name = "txt_Coverage";
            this.txt_Coverage.Size = new System.Drawing.Size(148, 26);
            this.txt_Coverage.TabIndex = 17;
            // 
            // txt_PlateNumber
            // 
            this.txt_PlateNumber.Location = new System.Drawing.Point(813, 62);
            this.txt_PlateNumber.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_PlateNumber.Name = "txt_PlateNumber";
            this.txt_PlateNumber.Size = new System.Drawing.Size(148, 26);
            this.txt_PlateNumber.TabIndex = 18;
            // 
            // txt_ModelYear
            // 
            this.txt_ModelYear.Location = new System.Drawing.Point(237, 155);
            this.txt_ModelYear.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_ModelYear.Name = "txt_ModelYear";
            this.txt_ModelYear.Size = new System.Drawing.Size(148, 26);
            this.txt_ModelYear.TabIndex = 20;
            // 
            // txt_Brand
            // 
            this.txt_Brand.Location = new System.Drawing.Point(429, 155);
            this.txt_Brand.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_Brand.Name = "txt_Brand";
            this.txt_Brand.Size = new System.Drawing.Size(148, 26);
            this.txt_Brand.TabIndex = 21;
            // 
            // lbl_CID
            // 
            this.lbl_CID.AutoSize = true;
            this.lbl_CID.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CID.Location = new System.Drawing.Point(57, 31);
            this.lbl_CID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_CID.Name = "lbl_CID";
            this.lbl_CID.Size = new System.Drawing.Size(95, 25);
            this.lbl_CID.TabIndex = 25;
            this.lbl_CID.Text = "Client ID";
            this.lbl_CID.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // lbl__Price
            // 
            this.lbl__Price.AutoSize = true;
            this.lbl__Price.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl__Price.Location = new System.Drawing.Point(432, 29);
            this.lbl__Price.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl__Price.Name = "lbl__Price";
            this.lbl__Price.Size = new System.Drawing.Size(61, 25);
            this.lbl__Price.TabIndex = 26;
            this.lbl__Price.Text = "Price";
            // 
            // lbl_Coverage
            // 
            this.lbl_Coverage.AutoSize = true;
            this.lbl_Coverage.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Coverage.Location = new System.Drawing.Point(612, 29);
            this.lbl_Coverage.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Coverage.Name = "lbl_Coverage";
            this.lbl_Coverage.Size = new System.Drawing.Size(106, 25);
            this.lbl_Coverage.TabIndex = 27;
            this.lbl_Coverage.Text = "Coverage";
            // 
            // lbl_PlateNumber
            // 
            this.lbl_PlateNumber.AutoSize = true;
            this.lbl_PlateNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PlateNumber.Location = new System.Drawing.Point(808, 29);
            this.lbl_PlateNumber.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_PlateNumber.Name = "lbl_PlateNumber";
            this.lbl_PlateNumber.Size = new System.Drawing.Size(142, 25);
            this.lbl_PlateNumber.TabIndex = 28;
            this.lbl_PlateNumber.Text = "Plate Number";
            // 
            // lbl_ModelYear
            // 
            this.lbl_ModelYear.AutoSize = true;
            this.lbl_ModelYear.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ModelYear.Location = new System.Drawing.Point(243, 125);
            this.lbl_ModelYear.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_ModelYear.Name = "lbl_ModelYear";
            this.lbl_ModelYear.Size = new System.Drawing.Size(122, 25);
            this.lbl_ModelYear.TabIndex = 30;
            this.lbl_ModelYear.Text = "Model Year";
            // 
            // lbl_Brand
            // 
            this.lbl_Brand.AutoSize = true;
            this.lbl_Brand.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Brand.Location = new System.Drawing.Point(432, 125);
            this.lbl_Brand.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Brand.Name = "lbl_Brand";
            this.lbl_Brand.Size = new System.Drawing.Size(69, 25);
            this.lbl_Brand.TabIndex = 31;
            this.lbl_Brand.Text = "Brand";
            this.lbl_Brand.Click += new System.EventHandler(this.lbl_Brand_Click);
            // 
            // lbl_color
            // 
            this.lbl_color.AutoSize = true;
            this.lbl_color.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_color.Location = new System.Drawing.Point(628, 125);
            this.lbl_color.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_color.Name = "lbl_color";
            this.lbl_color.Size = new System.Drawing.Size(64, 25);
            this.lbl_color.TabIndex = 32;
            this.lbl_color.Text = "Color";
            // 
            // comboboxcolor
            // 
            this.comboboxcolor.FormattingEnabled = true;
            this.comboboxcolor.Location = new System.Drawing.Point(633, 155);
            this.comboboxcolor.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.comboboxcolor.Name = "comboboxcolor";
            this.comboboxcolor.Size = new System.Drawing.Size(240, 28);
            this.comboboxcolor.TabIndex = 33;
            this.comboboxcolor.SelectedIndexChanged += new System.EventHandler(this.comboboxcolor_SelectedIndexChanged);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LavenderBlush;
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel1.Location = new System.Drawing.Point(801, 266);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(309, 229);
            this.panel1.TabIndex = 47;
            // 
            // addPolicy
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LavenderBlush;
            this.ClientSize = new System.Drawing.Size(1200, 692);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.comboboxcolor);
            this.Controls.Add(this.lbl_color);
            this.Controls.Add(this.lbl_Brand);
            this.Controls.Add(this.lbl_ModelYear);
            this.Controls.Add(this.lbl_PlateNumber);
            this.Controls.Add(this.lbl_Coverage);
            this.Controls.Add(this.lbl__Price);
            this.Controls.Add(this.lbl_CID);
            this.Controls.Add(this.txt_Brand);
            this.Controls.Add(this.txt_ModelYear);
            this.Controls.Add(this.txt_PlateNumber);
            this.Controls.Add(this.txt_Coverage);
            this.Controls.Add(this.txt_Price);
            this.Controls.Add(this.txt_CID);
            this.Controls.Add(this.btn_View);
            this.Controls.Add(this.grid_pview);
            this.Controls.Add(this.lbl_model);
            this.Controls.Add(this.txt_Model);
            this.Controls.Add(this.btn_addPolicy);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MaximizeBox = false;
            this.Name = "addPolicy";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add Policy";
            this.Load += new System.EventHandler(this.addPolicy_Load);
            ((System.ComponentModel.ISupportInitialize)(this.database1DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.database1DataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grid_pview)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_addPolicy;
        private System.Windows.Forms.TextBox txt_Model;
        private System.Windows.Forms.Label lbl_model;
        private Database1DataSet database1DataSet;
        private System.Windows.Forms.BindingSource database1DataSetBindingSource;
        private System.Windows.Forms.DataGridView grid_pview;
        private System.Windows.Forms.Button btn_View;
        private System.Windows.Forms.TextBox txt_CID;
        private System.Windows.Forms.TextBox txt_Price;
        private System.Windows.Forms.TextBox txt_Coverage;
        private System.Windows.Forms.TextBox txt_PlateNumber;
        private System.Windows.Forms.TextBox txt_ModelYear;
        private System.Windows.Forms.TextBox txt_Brand;
        private System.Windows.Forms.Label lbl_CID;
        private System.Windows.Forms.Label lbl__Price;
        private System.Windows.Forms.Label lbl_Coverage;
        private System.Windows.Forms.Label lbl_PlateNumber;
        private System.Windows.Forms.Label lbl_ModelYear;
        private System.Windows.Forms.Label lbl_Brand;
        private System.Windows.Forms.Label lbl_color;
        private System.Windows.Forms.ComboBox comboboxcolor;
        private System.Windows.Forms.Panel panel1;
    }
}