﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;


namespace Project_take1
{

    public partial class dashboard : Form
    {
        public object UserControlEditAs1 { get; private set; }

        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn(int nLeftRect, int nTopRect, int nRightRect, int nBottomRect, int nWidthEllipse, int nHeightEllipse);

        public dashboard()
        { 
            InitializeComponent();

       
            customizeDesign();
            hideall();

            btn_As.Hide();
            btnemployee.Hide();

            userControl41.Show();
            if (frmReg.Ismanager == true)
            {
              
                btnemployee.Show();
                btn_As.Show();
                
            }
          
                hidesubmenu(panel2);
                panel2.Visible = false;
            hidesubmenu(panel2);
            panel3.Visible = false;

        }
        private void customizeDesign()
        {
            //panel2.Visible = false;
        }
        void hideall()
        {
            uCclient1.Hide();
            userControlViewEmpl1.Hide();
            userControl41.Hide();
            userControlEditAs1.Hide();
            userControlEmp2.Hide();
            userControlRemoveAs1.Hide();

            
        }
        private void hidesubmenu(Panel x)
        {
            if (x.Visible)
            {
                x.Visible = false;
            }
        }
        private void showsubmenu(Panel submenu)
        {
            if (submenu.Visible == false)
            {
               // hidesubmenu(submenu);
                submenu.Visible = true;
            }

            else
            {
                submenu.Visible = false;
            }
        }

        private void dashboard_Load(object sender, EventArgs e)
        {
            uCclient1.Hide();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
       
        private void button4_Click(object sender, EventArgs e)
        {

            new frmReg().Show();
            this.Hide();
        }

        private void button10_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void buttonSignOut_Click(object sender, EventArgs e)
        {
            var confirmResult = MessageBox.Show("Are you sure you want to sign out ?",
                                     "Confirm sign out",
                                     MessageBoxButtons.YesNo);
            if (confirmResult == DialogResult.Yes)
            {
                new frmReg().Show();
                this.Hide();
            }
        }

        private void buttonClient_Click(object sender, EventArgs e)
        { 
            hideall();
            uCclient1.Show();
            panel1.BackColor = Color.White;
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
           // hidesubmenu(panel2);
        }

        private void buttonRemove_Click(object sender, EventArgs e)
        {
           // hidesubmenu(panel2);
        }

        private void buttonView_Click(object sender, EventArgs e)
        {
            //hidesubmenu(panel2);
        }

        private void buttonEvaluate_Click(object sender, EventArgs e)
        {
           // hidesubmenu(panel2);
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            hideall();
            userControl41.Show();
            
     
            panel1.BackColor = Color.LavenderBlush;
        }

        private void button2_Click_1(object sender, EventArgs e)
        { 
              //  showsubmenu(pannelside);
           
        }

        private void pannelside_Paint(object sender, PaintEventArgs e)
        {

        }

        private void buttonSettings_Click(object sender, EventArgs e)
        {

        }

        private void userControl41_Load(object sender, EventArgs e)
        {

        }

        private void uCclient1_Load(object sender, EventArgs e)
        {
            
        }

        private void userControl41_Load_1(object sender, EventArgs e)
        {
          
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
          // panel1.BackColor = Color.LavenderBlush;
        }

        private void uCclient1_Load_1(object sender, EventArgs e)
        {
        }

        private void btnEmp_Click(object sender, EventArgs e)
        {
            hideall();
            userControlEmp2.Show();
   
        }

        private void userControl41_Load_2(object sender, EventArgs e)
        {

        }

        private void userControlEmp1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click_2(object sender, EventArgs e)
        {
            if (panel2.Visible == false)
            {
                hidesubmenu(panel2);
                panel2.Visible = true;
            }

            else
            {
                panel2.Visible = false;
            }
        }

        private void btn_ViewEmpl_Click(object sender, EventArgs e)
        {
            hideall();
            userControlViewEmpl1.Show();
        }

        private void userControlViewEmpl1_Load(object sender, EventArgs e)
        {

        }

        private void btn_As_Click(object sender, EventArgs e)
        {
            if (panel3.Visible == false)
            {
                hidesubmenu(panel3);
                panel3.Visible = true;
            }

            else
            {
                panel3.Visible = false;
            }
        }

        private void btn_editAs_Click(object sender, EventArgs e)
        {
            hideall();
            userControlEditAs1.Show();
        }

        private void btn_ViewAs_Click(object sender, EventArgs e)
        {
            hideall();
            userControlRemoveAs1.Show();

        }

        private void userControlRemoveAs1_Load(object sender, EventArgs e)
        {

        }
    }
}
