﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net.Configuration;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Project_take1
{
    public partial class addPolicy : Form
    {
        SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["myDB"].ToString());

        public addPolicy()
        {
            InitializeComponent();
            //get all colors using type of color
            comboboxcolor.DataSource = typeof(Color).GetProperties()
            .Where(x => x.PropertyType == typeof(Color))
            .Select(x => x.GetValue(null)).ToList();
            //display only 10 values in combobox
            comboboxcolor.MaxDropDownItems = 10;
            comboboxcolor.IntegralHeight = false;
            comboboxcolor.DrawMode = DrawMode.OwnerDrawFixed;
            comboboxcolor.DropDownStyle = ComboBoxStyle.DropDownList;
            comboboxcolor.DrawItem += comboboxcolor_DrawItem;

            string query = "select * from Vehicle_Policy";
            SqlDataAdapter adapter = new SqlDataAdapter(query, con);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            grid_pview.DataSource = dt;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void addPolicy_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_addPolicy_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txt_Model.Text) || string.IsNullOrEmpty(txt_CID.Text) ||
    string.IsNullOrEmpty(txt_Price.Text) || string.IsNullOrEmpty(txt_Coverage.Text) ||
    string.IsNullOrEmpty(txt_PlateNumber.Text) || string.IsNullOrEmpty(txt_ModelYear.Text) ||
    string.IsNullOrEmpty(txt_Brand.Text) || string.IsNullOrEmpty(comboboxcolor.Text))
            {
                MessageBox.Show("Please fill in all the required information.");
                return;
            }
            DateTime startDate = DateTime.Today;
            DateTime endDate = startDate.AddYears(1);
            int pass = 1, i = 0;

            string Select = "SELECT Active FROM Vehicle_Policy WHERE Plate_Number = @Plate_Number";
            SqlCommand cmds = new SqlCommand(Select, con);

            try
            {
                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }

                cmds.Parameters.AddWithValue("@Plate_Number", txt_PlateNumber.Text);

                SqlDataReader reader = cmds.ExecuteReader();
                List<int> results = new List<int>();

                while (reader.Read())
                {
                    int value = (int)reader["Active"];
                    results.Add(value);
                }

                reader.Close();

                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }

                while (i < results.Count && pass == 0)
                {
                    if (results[0] == 1)
                        pass = 0;
                    i++;
                }

                if (pass == 1)
                {
                    if (comboboxcolor.Text == "Transparent")
                        MessageBox.Show("Please choose a color");
                    else
                    {
                        string Insert_Policy = "INSERT INTO Vehicle_Policy Values (@C_ID, @Model, @Price, @Coverage, @Plate_number, @Model_Year, @Brand, @Color, @Start_Date, @Expiry_Date, @Active, @Paid_From_Coverage)";
                        SqlCommand cmd = new SqlCommand(Insert_Policy, con);
                        try
                        {
                            cmd.Parameters.AddWithValue("@Model", txt_Model.Text);
                            cmd.Parameters.AddWithValue("@Start_Date", startDate);
                            cmd.Parameters.AddWithValue("@Expiry_Date", endDate);
                            cmd.Parameters.AddWithValue("@C_ID", int.Parse(txt_CID.Text));
                            cmd.Parameters.AddWithValue("@Price", int.Parse(txt_Price.Text));
                            cmd.Parameters.AddWithValue("@Coverage", int.Parse(txt_Coverage.Text));
                            cmd.Parameters.AddWithValue("@Plate_number", txt_PlateNumber.Text);
                            cmd.Parameters.AddWithValue("@Model_Year", int.Parse(txt_ModelYear.Text));
                            cmd.Parameters.AddWithValue("@Brand", txt_Brand.Text);
                            cmd.Parameters.AddWithValue("@Color", comboboxcolor.Text);
                            cmd.Parameters.AddWithValue("@Active", true);
                            cmd.Parameters.AddWithValue("@Paid_From_Coverage", 0);

                            if (con.State != ConnectionState.Open)
                            {
                                con.Open();
                            }
                            cmd.ExecuteNonQuery();


                            MessageBox.Show("Policy added successfully.");

                            string query = "select * from Vehicle_Policy";
                            SqlDataAdapter adapter = new SqlDataAdapter(query, con);
                            DataTable dt = new DataTable();
                            adapter.Fill(dt);
                            grid_pview.DataSource = dt;

                            if (con.State == ConnectionState.Open)
                            {
                                con.Close();
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("An error occurred:Client ID does not exist or data not filled correctly");

                        }
                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("An already Active Policy for this Vehicle exist");
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_model_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void grid_pview_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btn_View_Click(object sender, EventArgs e)
        {
            if (con.State != ConnectionState.Closed)
            {
                con.Close();
            }
            string query = "select * from Vehicle_Policy";
            SqlDataAdapter adapter = new SqlDataAdapter(query, con);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            grid_pview.DataSource = dt;
        }


        private void txt_PolicyNumber_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboboxcolor_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void comboboxcolor_DrawItem(object sender, DrawItemEventArgs e)
        {
            e.DrawBackground();
            if (e.Index >= 0)
            {
                var txt = comboboxcolor.GetItemText(comboboxcolor.Items[e.Index]);
                var color = (Color)comboboxcolor.Items[e.Index];
                var r1 = new Rectangle(e.Bounds.Left + 1, e.Bounds.Top + 1,
                    2 * (e.Bounds.Height - 2), e.Bounds.Height - 2);
                var r2 = Rectangle.FromLTRB(r1.Right + 2, e.Bounds.Top,
                    e.Bounds.Right, e.Bounds.Bottom);
                using (var b = new SolidBrush(color))
                    e.Graphics.FillRectangle(b, r1);
                e.Graphics.DrawRectangle(Pens.Black, r1);
                TextRenderer.DrawText(e.Graphics, txt, comboboxcolor.Font, r2,
                    comboboxcolor.ForeColor, TextFormatFlags.Left | TextFormatFlags.VerticalCenter);
            }
        }

        private void lbl_Brand_Click(object sender, EventArgs e)
        {

        }
    }
}
