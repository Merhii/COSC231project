﻿namespace Project_take1
{
    partial class Accident
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Accident));
            this.lbl_ClientID = new System.Windows.Forms.Label();
            this.lbl_AS = new System.Windows.Forms.Label();
            this.lbl_Place = new System.Windows.Forms.Label();
            this.lbl_Date = new System.Windows.Forms.Label();
            this.lbl_Acceptance = new System.Windows.Forms.Label();
            this.lbl_Expenses = new System.Windows.Forms.Label();
            this.txt_Expenses = new System.Windows.Forms.TextBox();
            this.txt_Place = new System.Windows.Forms.TextBox();
            this.txt_ASID = new System.Windows.Forms.TextBox();
            this.txt_ClientID = new System.Windows.Forms.TextBox();
            this.grd_Accident = new System.Windows.Forms.DataGridView();
            this.btn_addAccident = new System.Windows.Forms.Button();
            this.VIEW = new System.Windows.Forms.Button();
            this.txt_PolicyNumber = new System.Windows.Forms.TextBox();
            this.lbl_PolicyNumber = new System.Windows.Forms.Label();
            this.Date_of_Accident = new System.Windows.Forms.DateTimePicker();
            this.panel1 = new System.Windows.Forms.Panel();
            this.rd_yes = new System.Windows.Forms.RadioButton();
            this.rd_no = new System.Windows.Forms.RadioButton();
            ((System.ComponentModel.ISupportInitialize)(this.grd_Accident)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_ClientID
            // 
            this.lbl_ClientID.AutoSize = true;
            this.lbl_ClientID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ClientID.Location = new System.Drawing.Point(72, 25);
            this.lbl_ClientID.Name = "lbl_ClientID";
            this.lbl_ClientID.Size = new System.Drawing.Size(79, 20);
            this.lbl_ClientID.TabIndex = 0;
            this.lbl_ClientID.Text = "Client ID";
            // 
            // lbl_AS
            // 
            this.lbl_AS.AutoSize = true;
            this.lbl_AS.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AS.Location = new System.Drawing.Point(211, 25);
            this.lbl_AS.Name = "lbl_AS";
            this.lbl_AS.Size = new System.Drawing.Size(111, 20);
            this.lbl_AS.TabIndex = 1;
            this.lbl_AS.Text = "Specialist ID";
            // 
            // lbl_Place
            // 
            this.lbl_Place.AutoSize = true;
            this.lbl_Place.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Place.Location = new System.Drawing.Point(376, 25);
            this.lbl_Place.Name = "lbl_Place";
            this.lbl_Place.Size = new System.Drawing.Size(53, 20);
            this.lbl_Place.TabIndex = 2;
            this.lbl_Place.Text = "Place";
            // 
            // lbl_Date
            // 
            this.lbl_Date.AutoSize = true;
            this.lbl_Date.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Date.Location = new System.Drawing.Point(229, 98);
            this.lbl_Date.Name = "lbl_Date";
            this.lbl_Date.Size = new System.Drawing.Size(147, 20);
            this.lbl_Date.TabIndex = 3;
            this.lbl_Date.Text = "Date Of Accident";
            this.lbl_Date.Click += new System.EventHandler(this.lbl_Date_Click);
            // 
            // lbl_Acceptance
            // 
            this.lbl_Acceptance.AutoSize = true;
            this.lbl_Acceptance.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Acceptance.Location = new System.Drawing.Point(688, 25);
            this.lbl_Acceptance.Name = "lbl_Acceptance";
            this.lbl_Acceptance.Size = new System.Drawing.Size(85, 20);
            this.lbl_Acceptance.TabIndex = 4;
            this.lbl_Acceptance.Text = "Covered?";
            this.lbl_Acceptance.Click += new System.EventHandler(this.lbl_Acceptance_Click);
            // 
            // lbl_Expenses
            // 
            this.lbl_Expenses.AutoSize = true;
            this.lbl_Expenses.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Expenses.Location = new System.Drawing.Point(533, 25);
            this.lbl_Expenses.Name = "lbl_Expenses";
            this.lbl_Expenses.Size = new System.Drawing.Size(87, 20);
            this.lbl_Expenses.TabIndex = 5;
            this.lbl_Expenses.Text = "Expenses";
            this.lbl_Expenses.Click += new System.EventHandler(this.label6_Click);
            // 
            // txt_Expenses
            // 
            this.txt_Expenses.Location = new System.Drawing.Point(536, 58);
            this.txt_Expenses.Name = "txt_Expenses";
            this.txt_Expenses.Size = new System.Drawing.Size(110, 20);
            this.txt_Expenses.TabIndex = 6;
            this.txt_Expenses.TextChanged += new System.EventHandler(this.txt_Expenses_TextChanged);
            // 
            // txt_Place
            // 
            this.txt_Place.Location = new System.Drawing.Point(379, 58);
            this.txt_Place.Name = "txt_Place";
            this.txt_Place.Size = new System.Drawing.Size(120, 20);
            this.txt_Place.TabIndex = 9;
            // 
            // txt_ASID
            // 
            this.txt_ASID.Location = new System.Drawing.Point(214, 58);
            this.txt_ASID.Name = "txt_ASID";
            this.txt_ASID.Size = new System.Drawing.Size(131, 20);
            this.txt_ASID.TabIndex = 10;
            // 
            // txt_ClientID
            // 
            this.txt_ClientID.Location = new System.Drawing.Point(64, 58);
            this.txt_ClientID.Name = "txt_ClientID";
            this.txt_ClientID.Size = new System.Drawing.Size(122, 20);
            this.txt_ClientID.TabIndex = 11;
            // 
            // grd_Accident
            // 
            this.grd_Accident.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.grd_Accident.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grd_Accident.Location = new System.Drawing.Point(19, 197);
            this.grd_Accident.Name = "grd_Accident";
            this.grd_Accident.RowHeadersWidth = 51;
            this.grd_Accident.Size = new System.Drawing.Size(428, 243);
            this.grd_Accident.TabIndex = 12;
            this.grd_Accident.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.grd_Accident_CellContentClick);
            // 
            // btn_addAccident
            // 
            this.btn_addAccident.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.btn_addAccident.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_addAccident.ForeColor = System.Drawing.Color.White;
            this.btn_addAccident.Location = new System.Drawing.Point(622, 143);
            this.btn_addAccident.Name = "btn_addAccident";
            this.btn_addAccident.Size = new System.Drawing.Size(128, 41);
            this.btn_addAccident.TabIndex = 13;
            this.btn_addAccident.Text = "ADD ACCIDENT";
            this.btn_addAccident.UseVisualStyleBackColor = false;
            this.btn_addAccident.Click += new System.EventHandler(this.btn_addAccident_Click);
            // 
            // VIEW
            // 
            this.VIEW.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.VIEW.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.VIEW.ForeColor = System.Drawing.Color.White;
            this.VIEW.Location = new System.Drawing.Point(464, 405);
            this.VIEW.Name = "VIEW";
            this.VIEW.Size = new System.Drawing.Size(165, 35);
            this.VIEW.TabIndex = 14;
            this.VIEW.Text = "VIEW ACCIDENTS";
            this.VIEW.UseVisualStyleBackColor = false;
            this.VIEW.Click += new System.EventHandler(this.VIEW_Click);
            // 
            // txt_PolicyNumber
            // 
            this.txt_PolicyNumber.Location = new System.Drawing.Point(64, 130);
            this.txt_PolicyNumber.Name = "txt_PolicyNumber";
            this.txt_PolicyNumber.Size = new System.Drawing.Size(122, 20);
            this.txt_PolicyNumber.TabIndex = 19;
            this.txt_PolicyNumber.TextChanged += new System.EventHandler(this.txt_PolicyNumber_TextChanged);
            // 
            // lbl_PolicyNumber
            // 
            this.lbl_PolicyNumber.AutoSize = true;
            this.lbl_PolicyNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PolicyNumber.Location = new System.Drawing.Point(72, 98);
            this.lbl_PolicyNumber.Name = "lbl_PolicyNumber";
            this.lbl_PolicyNumber.Size = new System.Drawing.Size(122, 20);
            this.lbl_PolicyNumber.TabIndex = 22;
            this.lbl_PolicyNumber.Text = "Policy Number";
            this.lbl_PolicyNumber.Click += new System.EventHandler(this.lbl_PolicyNumber_Click);
            // 
            // Date_of_Accident
            // 
            this.Date_of_Accident.Location = new System.Drawing.Point(206, 128);
            this.Date_of_Accident.Name = "Date_of_Accident";
            this.Date_of_Accident.Size = new System.Drawing.Size(182, 20);
            this.Date_of_Accident.TabIndex = 23;
            this.Date_of_Accident.ValueChanged += new System.EventHandler(this.Date_of_Accident_ValueChanged);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LavenderBlush;
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel1.Location = new System.Drawing.Point(481, 197);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(234, 182);
            this.panel1.TabIndex = 46;
            // 
            // rd_yes
            // 
            this.rd_yes.AutoSize = true;
            this.rd_yes.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rd_yes.Location = new System.Drawing.Point(692, 56);
            this.rd_yes.Margin = new System.Windows.Forms.Padding(2);
            this.rd_yes.Name = "rd_yes";
            this.rd_yes.Size = new System.Drawing.Size(58, 24);
            this.rd_yes.TabIndex = 47;
            this.rd_yes.TabStop = true;
            this.rd_yes.Text = "Yes";
            this.rd_yes.UseVisualStyleBackColor = true;
            this.rd_yes.CheckedChanged += new System.EventHandler(this.rd_yes_CheckedChanged);
            // 
            // rd_no
            // 
            this.rd_no.AutoSize = true;
            this.rd_no.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rd_no.Location = new System.Drawing.Point(692, 84);
            this.rd_no.Margin = new System.Windows.Forms.Padding(2);
            this.rd_no.Name = "rd_no";
            this.rd_no.Size = new System.Drawing.Size(49, 24);
            this.rd_no.TabIndex = 48;
            this.rd_no.TabStop = true;
            this.rd_no.Text = "No";
            this.rd_no.UseVisualStyleBackColor = true;
            // 
            // Accident
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LavenderBlush;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.rd_no);
            this.Controls.Add(this.rd_yes);
            this.Controls.Add(this.VIEW);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.Date_of_Accident);
            this.Controls.Add(this.lbl_PolicyNumber);
            this.Controls.Add(this.txt_PolicyNumber);
            this.Controls.Add(this.btn_addAccident);
            this.Controls.Add(this.grd_Accident);
            this.Controls.Add(this.txt_ClientID);
            this.Controls.Add(this.txt_ASID);
            this.Controls.Add(this.txt_Place);
            this.Controls.Add(this.txt_Expenses);
            this.Controls.Add(this.lbl_Expenses);
            this.Controls.Add(this.lbl_Acceptance);
            this.Controls.Add(this.lbl_Date);
            this.Controls.Add(this.lbl_Place);
            this.Controls.Add(this.lbl_AS);
            this.Controls.Add(this.lbl_ClientID);
            this.MaximizeBox = false;
            this.Name = "Accident";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Accident";
            this.Load += new System.EventHandler(this.Accident_Load);
            ((System.ComponentModel.ISupportInitialize)(this.grd_Accident)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_ClientID;
        private System.Windows.Forms.Label lbl_AS;
        private System.Windows.Forms.Label lbl_Place;
        private System.Windows.Forms.Label lbl_Date;
        private System.Windows.Forms.Label lbl_Acceptance;
        private System.Windows.Forms.Label lbl_Expenses;
        private System.Windows.Forms.TextBox txt_Expenses;
        private System.Windows.Forms.TextBox txt_Place;
        private System.Windows.Forms.TextBox txt_ASID;
        private System.Windows.Forms.TextBox txt_ClientID;
        private System.Windows.Forms.DataGridView grd_Accident;
        private System.Windows.Forms.Button btn_addAccident;
        private System.Windows.Forms.Button VIEW;
        private System.Windows.Forms.TextBox txt_PolicyNumber;
        private System.Windows.Forms.Label lbl_PolicyNumber;
        private System.Windows.Forms.DateTimePicker Date_of_Accident;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton rd_yes;
        private System.Windows.Forms.RadioButton rd_no;
    }
}