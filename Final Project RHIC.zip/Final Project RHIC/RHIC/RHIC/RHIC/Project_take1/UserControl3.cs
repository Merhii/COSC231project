﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;

namespace Project_take1
{
    public partial class UCclient : UserControl
    {
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn(int nLeftRect, int nTopRect, int nRightRect, int nBottomRect, int nWidthEllipse, int nHeightEllipse);

        public UCclient()
        {
            
            InitializeComponent();
          
                panel1.Visible = false;
            void RoundButton(Button x)
            {
                x.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, x.Width, x.Height, 30, 30));
                this.Controls.Add(x);
            }
            RoundButton(btnev);
            RoundButton(btnadd);
            RoundButton(btnview);
            RoundButton(btn_Accident);
            RoundButton(btn_Policy);
            RoundButton(View_Acc);
          // btn_evpol.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, btn_evpol.Width, btn_evpol.Height, 30, 30));
            //this.Controls.Add(btn_evpol);
         //  btn_evacc.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, btn_evacc.Width, btn_evacc.Height, 30, 30));
         // this.Controls.Add(btn_evacc);
        }

        public static object Control { get; internal set; }

        private void btnadd_Click(object sender, EventArgs e)
        { 
          
        }

        private void btnview_Click(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
          
        }

        private void btn_Accident_Click(object sender, EventArgs e)
        {
           
        }

        private void btnview_Click_1(object sender, EventArgs e)
        {
          

            new btn_ViewForm().Show();

        }

        private void btn_Accident_Click_1(object sender, EventArgs e)
        {
           

            new Accident().Show();
        }

        private void btn_Policy_Click(object sender, EventArgs e)
        {
            

            new addPolicy().Show();
        }

        private void btnadd_Click_1(object sender, EventArgs e)
        {
            
          
            new Form2().Show();
        }

      
        private void btnev_Click(object sender, EventArgs e)
        {
          

            if (panel1.Visible == false)
            {
                if (panel1.Visible)
                {
                    panel1.Visible = false;
                }
                panel1.Visible = true;
            }

            else
            {
                panel1.Visible = false;
            }

        }

        private void UCclient_Load(object sender, EventArgs e)
        {

        }

        private void btn_pay_Click(object sender, EventArgs e)
        {
            
        }

        private void btn_pay_Click_1(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            new FormAcc().Show();
        }

        private void btn_evpol_Click(object sender, EventArgs e)
        {
            new Evaluate().Show();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btn_evacc_Click(object sender, EventArgs e)
        {
            new Acc_Evaluate().Show();
        }
    }
}
