﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_take1
{
    public partial class UserControlEditAs : UserControl
    {
        SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["myDB"].ToString());

        public UserControlEditAs()
        {
            InitializeComponent();
            btn_Removee.Hide();
            txt_IDe.Hide();
            labelID.Hide();
            btn_Adde.Hide();
            txt_emaile.Hide();
            txt_Namee.Hide();
            txt_Phone.Hide();
            labelpass.Hide();
            label2.Hide();
            label3.Hide();
            label1.Hide();
            txt_Address.Hide();
           
        }

        private void btn_Removee_Click(object sender, EventArgs e)
        {
            int ID = 0;

                var confirmResult = MessageBox.Show("Are you sure you want to remove this specialist ?",
                                     "Confirm action",
                                     MessageBoxButtons.YesNo);
            try
            {
                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }

                string SelectEID = "SELECT AS_ID FROM Accident_Specialist WHERE AS_ID = @ID";
                SqlCommand cmds = new SqlCommand(SelectEID, con);
                cmds.Parameters.AddWithValue("@ID", int.Parse(txt_IDe.Text));
                object result = cmds.ExecuteScalar();

                if (result != null)
                    ID = int.Parse(result.ToString());
                else
                    throw new Exception("The ID You Entered Doesn't Exist");

                if (confirmResult == DialogResult.Yes)
                {
                    string query1 = "Delete FROM Accident_Specialist where AS_ID=@AS_ID";
                    SqlCommand cmd = new SqlCommand(query1, con);
                    cmd.Parameters.AddWithValue("@AS_ID", int.Parse(txt_IDe.Text));
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Specialist Removed Successfully");
                    txt_IDe.Text = "";
                }
               

                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            catch (Exception msg)
            {

                MessageBox.Show("Please Enter Correct ID to Remove The Corresponding Specialist");
            }
        }

        private void btn_Adde_Click(object sender, EventArgs e)
        {
            try
            {

                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }

                string query1 = "INSERT INTO Accident_Specialist VALUES (@Name, @Phone_Number, @Email, @Address); SELECT SCOPE_IDENTITY()";
                SqlCommand cmd = new SqlCommand(query1, con);
                cmd.Parameters.AddWithValue("@Name", txt_Namee.Text);
                cmd.Parameters.AddWithValue("@Email", txt_emaile.Text);
                cmd.Parameters.AddWithValue("@Phone_Number", txt_Phone.Text);
                cmd.Parameters.AddWithValue("@Address", txt_Address.Text);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Employee Added Successfully");
                txt_emaile.Text = "";
                txt_Namee.Text = "";
                txt_Phone.Text = "";
                txt_Address.Text = "";


                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            catch (Exception msg)
            {

                MessageBox.Show("Please Enter Correct Information");
            }

        }

        private void rd_Add_CheckedChanged(object sender, EventArgs e)
        {
            btn_Removee.Hide();
            labelID.Hide();
            txt_IDe.Hide();
            labelpass.Show();
            label2.Show();
            label3.Show();
            label1.Show();
            txt_emaile.Show();
            txt_Namee.Show();
            txt_Address.Show();
            txt_Phone.Show();
            btn_Adde.Show();
        }

        private void rd_Remove_CheckedChanged(object sender, EventArgs e)
        {

            btn_Adde.Hide();
            txt_emaile.Hide();
            txt_Namee.Hide();
            txt_Address.Hide();
            labelpass.Hide();
            label2.Hide();
            label3.Hide();
            label1.Hide();
            btn_Adde.Hide();
            labelID.Show();
            txt_IDe.Show();
            btn_Removee.Show();
            txt_Phone.Hide();
        }

        private void UserControlEditAs_Load(object sender, EventArgs e)
        {

        }

        private void txt_Namee_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
