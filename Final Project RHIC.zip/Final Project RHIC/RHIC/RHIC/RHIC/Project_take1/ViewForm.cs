﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Project_take1
{
    public partial class btn_ViewForm : Form
    {
        SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["myDB"].ToString());
        

        public btn_ViewForm()
        {
            InitializeComponent();

            string SClient = "select * from Client";
            SqlDataAdapter adapter = new SqlDataAdapter(SClient, con);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            grid_ClientView.DataSource = dt;

            string SPolicy = "select * from Vehicle_Policy";
            SqlDataAdapter adapter2 = new SqlDataAdapter(SPolicy, con);
            DataTable dt2 = new DataTable();
            adapter2.Fill(dt2);
            datagridviewPolicy.DataSource = dt2;
        }

        private void ViewClients_Click(object sender, EventArgs e)
        {
            string query = "select * from Client";
            SqlDataAdapter adapter = new SqlDataAdapter(query, con);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
           grid_ClientView.DataSource = dt;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btn_ViewForm_Load(object sender, EventArgs e)
        {

        }

        private void btn_Search_Click(object sender, EventArgs e)
        {
            

        }

        private void txt_search_TextChanged(object sender, EventArgs e)
        {
            string query = "SELECT * FROM Client WHERE Name LIKE @Name";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@Name", txt_search.Text + '%');

            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            grid_ClientView.DataSource = dt;
        }

        private void txt_viewPolicy_TextChanged(object sender, EventArgs e)
        {
            string query = "SELECT * FROM Vehicle_Policy WHERE C_ID LIKE @C_ID";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@C_ID", txt_viewPolicy.Text + '%');

            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            datagridviewPolicy.DataSource = dt;
        }

        private void buttonviewPolicy_Click(object sender, EventArgs e)
        {
            string query = "select * from Vehicle_Policy";
            SqlDataAdapter adapter = new SqlDataAdapter(query, con);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            datagridviewPolicy.DataSource = dt;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void datagridviewPolicy_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnedit_Click(object sender, EventArgs e)
        {
            new Clientedit().Show();
            
        }

        private void btneditp_Click(object sender, EventArgs e)
        {
            new Policyedit().Show();    
    
        }
    }
}
