﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_take1
{
    public partial class FormAcc : Form
    {
        public FormAcc()
        {
            InitializeComponent();

            SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["myDB"].ToString());
            string query = "select * from Accident";
            SqlDataAdapter adapter = new SqlDataAdapter(query, con);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            datagridviewPolicy.DataSource = dt;
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void txt_viewPolicy_TextChanged(object sender, EventArgs e)
        {
            if (rd_as.Checked)
            {
                SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["myDB"].ToString());
                string query = "SELECT Client.Name,Accident_Specialist.Name, Accident.*  FROM Accident_Specialist Inner join Accident on Accident.As_ID= Accident_Specialist.As_ID inner join Client on Accident.C_ID= Client.C_ID WHERE Accident_Specialist.Name LIKE @Name";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@Name", txt_viewPolicy.Text + '%');

                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                datagridviewPolicy.DataSource = dt;

            }
            else if (rd_Client.Checked) 
            {

                SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["myDB"].ToString());
                string query = "SELECT Client.Name,Accident_Specialist.Name, Accident.*  FROM Accident_Specialist Inner join Accident on Accident.As_ID= Accident_Specialist.As_ID inner join Client on Accident.C_ID= Client.C_ID WHERE Client.Name LIKE @Name";
                SqlCommand cmd2 = new SqlCommand(query, con);
                cmd2.Parameters.AddWithValue("@Name", txt_viewPolicy.Text + '%');

                SqlDataAdapter adapter = new SqlDataAdapter(cmd2);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                datagridviewPolicy.DataSource = dt;

            }
        }

        private void buttonviewPolicy_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["myDB"].ToString());
            string query = "select * from Accident";
            SqlDataAdapter adapter = new SqlDataAdapter(query, con);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            datagridviewPolicy.DataSource = dt;
        }

        private void FormAcc_Load(object sender, EventArgs e)
        {

        }
    }
}
