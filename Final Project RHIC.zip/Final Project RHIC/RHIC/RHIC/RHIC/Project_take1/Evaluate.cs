﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Imaging;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;



namespace Project_take1
{
    public partial class Evaluate : Form
    {
        
       
        SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["myDB"].ToString());
        
        public Evaluate()
        {
            InitializeComponent();
            Draw_Chart();
        }


        private void Draw_Chart()
        {
            chart_Evaluate.Series.Clear();

            int year = date_year.Value.Year;

            DataTable dt = new DataTable();
            string sql = "SELECT MONTH(Start_Date) AS Month, Brand, COUNT(*) AS Policy_Count " +
                         "FROM Vehicle_Policy " +
                         "WHERE YEAR(Start_Date) = @Year " +
                         "GROUP BY Brand, MONTH(Start_Date) " +
                         "ORDER BY MONTH(Start_Date)";

            using (SqlCommand cmd = new SqlCommand(sql, con))
            {
                cmd.Parameters.AddWithValue("@Year", year);

                try
                {
                    if (con.State != ConnectionState.Open)
                    {
                        con.Open();
                    }

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);

                    // create a series for each brand
                    var seriesDict = new Dictionary<string, Series>();
                    foreach (DataRow row in dt.Rows)
                    {
                        string brand = row["Brand"].ToString();
                        if (!seriesDict.ContainsKey(brand))
                        {
                            seriesDict[brand] = chart_Evaluate.Series.Add(brand);
                            seriesDict[brand].ChartType = SeriesChartType.Column;
                        }
                    }

                    // add data points to each series
                    foreach (DataRow row in dt.Rows)
                    {
                        string brand = row["Brand"].ToString();
                        int month = Convert.ToInt32(row["Month"]);
                        int policyCount = Convert.ToInt32(row["Policy_Count"]);

                        // Get the month name from the month number
                        string monthName = new DateTime(year, month, 1).ToString("MMMM");

                        DataPoint point = new DataPoint();
                        point.AxisLabel = monthName; // Set the label to the month name
                        point.SetValueXY(month, policyCount);
                        seriesDict[brand].Points.Add(point);
                        seriesDict[brand]["PixelPointWidth"] = "150"; // Change the value as needed

                    }

                    // set chart properties
                    chart_Evaluate.ChartAreas[0].AxisX.Interval = 1;
                    chart_Evaluate.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
                    chart_Evaluate.ChartAreas[0].AxisX.Title = "Month";
                    chart_Evaluate.ChartAreas[0].AxisX.IntervalType = DateTimeIntervalType.Number;
                    chart_Evaluate.ChartAreas[0].AxisX.IntervalOffset = 1;

                    chart_Evaluate.ChartAreas[0].AxisY.Title = "Policy Count";
                    chart_Evaluate.ChartAreas[0].AxisX.LabelStyle.Angle = -45; // or 90

                    chart_Evaluate.DataBind();

                    if (con.State == ConnectionState.Open)
                    {
                        con.Close();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An Error Occurred" + ex.Message);
                }
            }
        }

        private void Evaluate_Load(object sender, EventArgs e)
        {
            Draw_Chart();
            if (con.State != ConnectionState.Open)
            {
                con.Open();
            }
            lbl_income.Text = "";
            lbl_profit.Text = "";
            string query2 = "SELECT SUM(price) FROM Vehicle_Policy WHERE DATEPART(year, Start_Date) = @dateYear";
            SqlCommand cmd2 = new SqlCommand(query2, con);
            cmd2.Parameters.AddWithValue("@dateYear", date_year.Value.Year);
            object total = cmd2.ExecuteScalar();
            lbl_income.Text = total.ToString();
            string query = "SELECT SUM(Expenses) FROM Accident WHERE DATEPART(year, Date_Of_Acc) = @dateYear";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@dateYear", date_year.Value.Year);
            object expenses = cmd.ExecuteScalar();

            if (expenses != DBNull.Value && total != DBNull.Value)
            {
                int expensesint = Convert.ToInt32(expenses);
                int totalint = int.Parse(total.ToString());
                int profit = totalint - expensesint;
                lbl_profit.Text = profit.ToString();
            }

            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
        }

        private void chart_Evaluate_Click(object sender, EventArgs e)
        {

        }

        private void date_year_ValueChanged(object sender, EventArgs e)
        {
            Draw_Chart();
            if (con.State != ConnectionState.Open)
            {
                con.Open();
            }
            lbl_income.Text = "";
           lbl_profit.Text = "";
            string query2 = "SELECT SUM(price) FROM Vehicle_Policy WHERE DATEPART(year, Start_Date) = @dateYear";
            SqlCommand cmd2 = new SqlCommand(query2, con);
            cmd2.Parameters.AddWithValue("@dateYear", date_year.Value.Year);
            object total = cmd2.ExecuteScalar();
            
            lbl_income.Text = total.ToString();
            string query = "SELECT SUM(Expenses) FROM Accident WHERE DATEPART(year, Date_Of_Acc) = @dateYear";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@dateYear", date_year.Value.Year); 
            object expenses = cmd.ExecuteScalar();

            if (expenses != DBNull.Value && total != DBNull.Value)
            {
                int expensesint = Convert.ToInt32(expenses);
                int totalint = int.Parse(total.ToString());
                int profit = totalint - expensesint;
                lbl_profit.Text = profit.ToString();
            }

            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
        }
        private void btn_print_Click(object sender, EventArgs e)
        {
            // Save the chart as an image on the desktop
            string year = date_year.Value.Year.ToString();
            string imagePath = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory) + "\\Policies_" + year + ".png";
            chart_Evaluate.SaveImage(imagePath, ChartImageFormat.Png);

            MessageBox.Show("Chart saved as PNG on the desktop.");
        }

        private void txt_income_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_profit_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}

