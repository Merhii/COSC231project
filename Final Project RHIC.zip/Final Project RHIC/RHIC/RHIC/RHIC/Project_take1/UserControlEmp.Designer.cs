﻿using System;

namespace Project_take1
{
    partial class UserControlEmp
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UserControlEmp));
            this.txt_Password = new System.Windows.Forms.TextBox();
            this.labelpass = new System.Windows.Forms.Label();
            this.rd_manager1 = new System.Windows.Forms.RadioButton();
            this.rd_manager0 = new System.Windows.Forms.RadioButton();
            this.txt_Namee = new System.Windows.Forms.TextBox();
            this.txt_emaile = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.labelID = new System.Windows.Forms.Label();
            this.rd_Remove = new System.Windows.Forms.RadioButton();
            this.rd_Add = new System.Windows.Forms.RadioButton();
            this.btn_Removee = new System.Windows.Forms.Button();
            this.btn_Adde = new System.Windows.Forms.Button();
            this.txt_IDe = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.SuspendLayout();
            // 
            // txt_Password
            // 
            this.txt_Password.Location = new System.Drawing.Point(122, 256);
            this.txt_Password.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_Password.Name = "txt_Password";
            this.txt_Password.Size = new System.Drawing.Size(179, 22);
            this.txt_Password.TabIndex = 40;
            // 
            // labelpass
            // 
            this.labelpass.AutoSize = true;
            this.labelpass.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelpass.Location = new System.Drawing.Point(24, 258);
            this.labelpass.Name = "labelpass";
            this.labelpass.Size = new System.Drawing.Size(91, 20);
            this.labelpass.TabIndex = 39;
            this.labelpass.Text = "Password";
            // 
            // rd_manager1
            // 
            this.rd_manager1.AutoSize = true;
            this.rd_manager1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rd_manager1.Location = new System.Drawing.Point(168, 353);
            this.rd_manager1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rd_manager1.Name = "rd_manager1";
            this.rd_manager1.Size = new System.Drawing.Size(53, 24);
            this.rd_manager1.TabIndex = 38;
            this.rd_manager1.TabStop = true;
            this.rd_manager1.Text = "No";
            this.rd_manager1.UseVisualStyleBackColor = true;
            // 
            // rd_manager0
            // 
            this.rd_manager0.AutoSize = true;
            this.rd_manager0.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rd_manager0.Location = new System.Drawing.Point(168, 312);
            this.rd_manager0.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rd_manager0.Name = "rd_manager0";
            this.rd_manager0.Size = new System.Drawing.Size(61, 24);
            this.rd_manager0.TabIndex = 37;
            this.rd_manager0.TabStop = true;
            this.rd_manager0.Text = "Yes";
            this.rd_manager0.UseVisualStyleBackColor = true;
            // 
            // txt_Namee
            // 
            this.txt_Namee.Location = new System.Drawing.Point(122, 166);
            this.txt_Namee.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_Namee.Name = "txt_Namee";
            this.txt_Namee.Size = new System.Drawing.Size(179, 22);
            this.txt_Namee.TabIndex = 36;
            // 
            // txt_emaile
            // 
            this.txt_emaile.Location = new System.Drawing.Point(122, 209);
            this.txt_emaile.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_emaile.Name = "txt_emaile";
            this.txt_emaile.Size = new System.Drawing.Size(179, 22);
            this.txt_emaile.TabIndex = 35;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(32, 330);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 20);
            this.label4.TabIndex = 33;
            this.label4.Text = "Manager";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(25, 207);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 20);
            this.label3.TabIndex = 32;
            this.label3.Text = "E-mail";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(24, 166);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 20);
            this.label2.TabIndex = 31;
            this.label2.Text = "Name";
            // 
            // labelID
            // 
            this.labelID.AutoSize = true;
            this.labelID.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelID.Location = new System.Drawing.Point(30, 208);
            this.labelID.Name = "labelID";
            this.labelID.Size = new System.Drawing.Size(28, 20);
            this.labelID.TabIndex = 30;
            this.labelID.Text = "ID";
            // 
            // rd_Remove
            // 
            this.rd_Remove.AutoSize = true;
            this.rd_Remove.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rd_Remove.Location = new System.Drawing.Point(12, 106);
            this.rd_Remove.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rd_Remove.Name = "rd_Remove";
            this.rd_Remove.Size = new System.Drawing.Size(184, 24);
            this.rd_Remove.TabIndex = 29;
            this.rd_Remove.TabStop = true;
            this.rd_Remove.Text = "Remove Employee";
            this.rd_Remove.UseVisualStyleBackColor = true;
            this.rd_Remove.CheckedChanged += new System.EventHandler(this.rd_Remove_CheckedChanged);
            // 
            // rd_Add
            // 
            this.rd_Add.AutoSize = true;
            this.rd_Add.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rd_Add.Location = new System.Drawing.Point(13, 58);
            this.rd_Add.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rd_Add.Name = "rd_Add";
            this.rd_Add.Size = new System.Drawing.Size(149, 24);
            this.rd_Add.TabIndex = 28;
            this.rd_Add.TabStop = true;
            this.rd_Add.Text = "Add Employee";
            this.rd_Add.UseVisualStyleBackColor = true;
            this.rd_Add.CheckedChanged += new System.EventHandler(this.rd_Add_CheckedChanged_1);
            // 
            // btn_Removee
            // 
            this.btn_Removee.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.btn_Removee.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Removee.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Removee.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_Removee.Location = new System.Drawing.Point(520, 364);
            this.btn_Removee.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_Removee.Name = "btn_Removee";
            this.btn_Removee.Size = new System.Drawing.Size(201, 44);
            this.btn_Removee.TabIndex = 27;
            this.btn_Removee.Text = "Remove ";
            this.btn_Removee.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.btn_Removee.UseVisualStyleBackColor = false;
            this.btn_Removee.Click += new System.EventHandler(this.btn_Removee_Click);
            // 
            // btn_Adde
            // 
            this.btn_Adde.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.btn_Adde.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Adde.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Adde.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_Adde.Location = new System.Drawing.Point(520, 364);
            this.btn_Adde.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_Adde.Name = "btn_Adde";
            this.btn_Adde.Size = new System.Drawing.Size(201, 44);
            this.btn_Adde.TabIndex = 26;
            this.btn_Adde.Text = "Add ";
            this.btn_Adde.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.btn_Adde.UseVisualStyleBackColor = false;
            this.btn_Adde.Click += new System.EventHandler(this.btn_Adde_Click_1);
            // 
            // txt_IDe
            // 
            this.txt_IDe.Location = new System.Drawing.Point(122, 208);
            this.txt_IDe.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_IDe.Name = "txt_IDe";
            this.txt_IDe.Size = new System.Drawing.Size(179, 22);
            this.txt_IDe.TabIndex = 34;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LavenderBlush;
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel1.Location = new System.Drawing.Point(395, 24);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(416, 256);
            this.panel1.TabIndex = 41;
            // 
            // UserControlEmp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LavenderBlush;
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.txt_Password);
            this.Controls.Add(this.labelpass);
            this.Controls.Add(this.rd_manager1);
            this.Controls.Add(this.rd_manager0);
            this.Controls.Add(this.txt_Namee);
            this.Controls.Add(this.txt_emaile);
            this.Controls.Add(this.txt_IDe);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.labelID);
            this.Controls.Add(this.rd_Remove);
            this.Controls.Add(this.rd_Add);
            this.Controls.Add(this.btn_Removee);
            this.Controls.Add(this.btn_Adde);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "UserControlEmp";
            this.Size = new System.Drawing.Size(813, 475);
            this.Load += new System.EventHandler(this.UserControlEmp_Load_1);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

     

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txt_Password;
        private System.Windows.Forms.Label labelpass;
        private System.Windows.Forms.RadioButton rd_manager1;
        private System.Windows.Forms.RadioButton rd_manager0;
        private System.Windows.Forms.TextBox txt_Namee;
        private System.Windows.Forms.TextBox txt_emaile;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label labelID;
        private System.Windows.Forms.RadioButton rd_Remove;
        private System.Windows.Forms.RadioButton rd_Add;
        private System.Windows.Forms.Button btn_Removee;
        private System.Windows.Forms.Button btn_Adde;
        private readonly EventHandler UserControlEmp_Load;
        private System.Windows.Forms.TextBox txt_IDe;
    }
}
