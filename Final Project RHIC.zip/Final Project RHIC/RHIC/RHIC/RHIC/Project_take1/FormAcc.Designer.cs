﻿namespace Project_take1
{
    partial class FormAcc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txt_viewPolicy = new System.Windows.Forms.TextBox();
            this.buttonviewPolicy = new System.Windows.Forms.Button();
            this.datagridviewPolicy = new System.Windows.Forms.DataGridView();
            this.rd_as = new System.Windows.Forms.RadioButton();
            this.rd_Client = new System.Windows.Forms.RadioButton();
            ((System.ComponentModel.ISupportInitialize)(this.datagridviewPolicy)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.label1.Location = new System.Drawing.Point(10, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(257, 29);
            this.label1.TabIndex = 11;
            this.label1.Text = "Search for an accident ";
            // 
            // txt_viewPolicy
            // 
            this.txt_viewPolicy.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_viewPolicy.Location = new System.Drawing.Point(188, 72);
            this.txt_viewPolicy.Name = "txt_viewPolicy";
            this.txt_viewPolicy.Size = new System.Drawing.Size(181, 35);
            this.txt_viewPolicy.TabIndex = 10;
            this.txt_viewPolicy.TextChanged += new System.EventHandler(this.txt_viewPolicy_TextChanged);
            // 
            // buttonviewPolicy
            // 
            this.buttonviewPolicy.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.buttonviewPolicy.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonviewPolicy.ForeColor = System.Drawing.Color.White;
            this.buttonviewPolicy.Location = new System.Drawing.Point(351, 419);
            this.buttonviewPolicy.Name = "buttonviewPolicy";
            this.buttonviewPolicy.Size = new System.Drawing.Size(122, 33);
            this.buttonviewPolicy.TabIndex = 9;
            this.buttonviewPolicy.Text = "View Accidents";
            this.buttonviewPolicy.UseVisualStyleBackColor = false;
            this.buttonviewPolicy.Click += new System.EventHandler(this.buttonviewPolicy_Click);
            // 
            // datagridviewPolicy
            // 
            this.datagridviewPolicy.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.datagridviewPolicy.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datagridviewPolicy.Location = new System.Drawing.Point(70, 119);
            this.datagridviewPolicy.Name = "datagridviewPolicy";
            this.datagridviewPolicy.RowHeadersWidth = 51;
            this.datagridviewPolicy.Size = new System.Drawing.Size(618, 246);
            this.datagridviewPolicy.TabIndex = 8;
            // 
            // rd_as
            // 
            this.rd_as.AutoSize = true;
            this.rd_as.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rd_as.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.rd_as.Location = new System.Drawing.Point(392, 64);
            this.rd_as.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.rd_as.Name = "rd_as";
            this.rd_as.Size = new System.Drawing.Size(232, 21);
            this.rd_as.TabIndex = 12;
            this.rd_as.TabStop = true;
            this.rd_as.Text = "Search by Specialist\'s Name";
            this.rd_as.UseVisualStyleBackColor = true;
            this.rd_as.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // rd_Client
            // 
            this.rd_Client.AutoSize = true;
            this.rd_Client.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rd_Client.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.rd_Client.Location = new System.Drawing.Point(392, 93);
            this.rd_Client.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.rd_Client.Name = "rd_Client";
            this.rd_Client.Size = new System.Drawing.Size(203, 21);
            this.rd_Client.TabIndex = 13;
            this.rd_Client.TabStop = true;
            this.rd_Client.Text = "Search by Client\'s Name";
            this.rd_Client.UseVisualStyleBackColor = true;
            // 
            // FormAcc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LavenderBlush;
            this.ClientSize = new System.Drawing.Size(738, 375);
            this.Controls.Add(this.rd_Client);
            this.Controls.Add(this.rd_as);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_viewPolicy);
            this.Controls.Add(this.buttonviewPolicy);
            this.Controls.Add(this.datagridviewPolicy);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "FormAcc";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Accident Search";
            this.Load += new System.EventHandler(this.FormAcc_Load);
            ((System.ComponentModel.ISupportInitialize)(this.datagridviewPolicy)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_viewPolicy;
        private System.Windows.Forms.Button buttonviewPolicy;
        private System.Windows.Forms.DataGridView datagridviewPolicy;
        private System.Windows.Forms.RadioButton rd_as;
        private System.Windows.Forms.RadioButton rd_Client;
    }
}