﻿namespace Project_take1
{
    partial class UCclient
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UCclient));
            this.btn_Accident = new System.Windows.Forms.Button();
            this.btn_Policy = new System.Windows.Forms.Button();
            this.btnev = new System.Windows.Forms.Button();
            this.btnview = new System.Windows.Forms.Button();
            this.btnadd = new System.Windows.Forms.Button();
            this.View_Acc = new System.Windows.Forms.Button();
            this.database1DataSet1 = new Project_take1.Database1DataSet();
            this.btn_evacc = new System.Windows.Forms.Button();
            this.btn_evpol = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.database1DataSet1)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_Accident
            // 
            this.btn_Accident.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.btn_Accident.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn_Accident.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Accident.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Accident.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_Accident.Location = new System.Drawing.Point(224, 331);
            this.btn_Accident.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Accident.Name = "btn_Accident";
            this.btn_Accident.Size = new System.Drawing.Size(166, 36);
            this.btn_Accident.TabIndex = 7;
            this.btn_Accident.Text = "Add an Accident";
            this.btn_Accident.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.btn_Accident.UseVisualStyleBackColor = false;
            this.btn_Accident.Click += new System.EventHandler(this.btn_Accident_Click_1);
            // 
            // btn_Policy
            // 
            this.btn_Policy.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.btn_Policy.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Policy.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Policy.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_Policy.Location = new System.Drawing.Point(19, 331);
            this.btn_Policy.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Policy.Name = "btn_Policy";
            this.btn_Policy.Size = new System.Drawing.Size(151, 36);
            this.btn_Policy.TabIndex = 8;
            this.btn_Policy.Text = "Add Policy";
            this.btn_Policy.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.btn_Policy.UseVisualStyleBackColor = false;
            this.btn_Policy.Click += new System.EventHandler(this.btn_Policy_Click);
            // 
            // btnev
            // 
            this.btnev.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.btnev.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnev.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnev.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnev.Location = new System.Drawing.Point(430, 21);
            this.btnev.Margin = new System.Windows.Forms.Padding(2);
            this.btnev.Name = "btnev";
            this.btnev.Size = new System.Drawing.Size(151, 36);
            this.btnev.TabIndex = 9;
            this.btnev.Text = "Evaluate";
            this.btnev.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.btnev.UseVisualStyleBackColor = false;
            this.btnev.Click += new System.EventHandler(this.btnev_Click);
            // 
            // btnview
            // 
            this.btnview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.btnview.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnview.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnview.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnview.Location = new System.Drawing.Point(224, 21);
            this.btnview.Margin = new System.Windows.Forms.Padding(2);
            this.btnview.Name = "btnview";
            this.btnview.Size = new System.Drawing.Size(151, 36);
            this.btnview.TabIndex = 10;
            this.btnview.Text = "View Policies";
            this.btnview.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.btnview.UseVisualStyleBackColor = false;
            this.btnview.Click += new System.EventHandler(this.btnview_Click_1);
            // 
            // btnadd
            // 
            this.btnadd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.btnadd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnadd.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnadd.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnadd.Location = new System.Drawing.Point(19, 21);
            this.btnadd.Margin = new System.Windows.Forms.Padding(2);
            this.btnadd.Name = "btnadd";
            this.btnadd.Size = new System.Drawing.Size(151, 36);
            this.btnadd.TabIndex = 11;
            this.btnadd.Text = "Add a Client";
            this.btnadd.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.btnadd.UseVisualStyleBackColor = false;
            this.btnadd.Click += new System.EventHandler(this.btnadd_Click_1);
            // 
            // View_Acc
            // 
            this.View_Acc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.View_Acc.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.View_Acc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.View_Acc.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.View_Acc.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.View_Acc.Location = new System.Drawing.Point(430, 331);
            this.View_Acc.Margin = new System.Windows.Forms.Padding(2);
            this.View_Acc.Name = "View_Acc";
            this.View_Acc.Size = new System.Drawing.Size(162, 36);
            this.View_Acc.TabIndex = 12;
            this.View_Acc.Text = "View Accidents";
            this.View_Acc.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.View_Acc.UseVisualStyleBackColor = false;
            this.View_Acc.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // database1DataSet1
            // 
            this.database1DataSet1.DataSetName = "Database1DataSet";
            this.database1DataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // btn_evacc
            // 
            this.btn_evacc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.btn_evacc.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn_evacc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_evacc.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_evacc.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_evacc.Location = new System.Drawing.Point(-1, 30);
            this.btn_evacc.Margin = new System.Windows.Forms.Padding(2);
            this.btn_evacc.Name = "btn_evacc";
            this.btn_evacc.Size = new System.Drawing.Size(151, 36);
            this.btn_evacc.TabIndex = 13;
            this.btn_evacc.Text = "Accidents";
            this.btn_evacc.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.btn_evacc.UseVisualStyleBackColor = false;
            this.btn_evacc.Click += new System.EventHandler(this.btn_evacc_Click);
            // 
            // btn_evpol
            // 
            this.btn_evpol.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.btn_evpol.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn_evpol.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_evpol.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_evpol.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_evpol.Location = new System.Drawing.Point(-1, 0);
            this.btn_evpol.Margin = new System.Windows.Forms.Padding(2);
            this.btn_evpol.Name = "btn_evpol";
            this.btn_evpol.Size = new System.Drawing.Size(151, 36);
            this.btn_evpol.TabIndex = 14;
            this.btn_evpol.Text = "Policies";
            this.btn_evpol.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.btn_evpol.UseVisualStyleBackColor = false;
            this.btn_evpol.Click += new System.EventHandler(this.btn_evpol_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Controls.Add(this.btn_evpol);
            this.panel1.Controls.Add(this.btn_evacc);
            this.panel1.Location = new System.Drawing.Point(431, 56);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(150, 67);
            this.panel1.TabIndex = 15;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // UCclient
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LavenderBlush;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.View_Acc);
            this.Controls.Add(this.btnadd);
            this.Controls.Add(this.btnview);
            this.Controls.Add(this.btnev);
            this.Controls.Add(this.btn_Policy);
            this.Controls.Add(this.btn_Accident);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "UCclient";
            this.Size = new System.Drawing.Size(610, 386);
            this.Load += new System.EventHandler(this.UCclient_Load);
            ((System.ComponentModel.ISupportInitialize)(this.database1DataSet1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btn_Accident;
        private System.Windows.Forms.Button btn_Policy;
        private System.Windows.Forms.Button btnev;
        private System.Windows.Forms.Button btnview;
        private System.Windows.Forms.Button btnadd;
        private System.Windows.Forms.Button View_Acc;
        private Database1DataSet database1DataSet1;
        private System.Windows.Forms.Button btn_evacc;
        private System.Windows.Forms.Button btn_evpol;
        private System.Windows.Forms.Panel panel1;
    }
}
