﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using System.Xml.Linq;


namespace Project_take1
{
    public partial class Acc_Evaluate : Form
    {
        
        SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["myDB"].ToString());

        public Acc_Evaluate()
        {

            InitializeComponent();
            Draw_Chart();
            
    }

        private void date_year_ValueChanged(object sender, EventArgs e)
        {
            Draw_Chart();
            if (con.State != ConnectionState.Open)
            {
                con.Open();
            }
            string query = "SELECT COUNT(*) FROM Accident WHERE DATEPART(year, Date_Of_Acc) = @dateYear";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@dateYear", date_year.Value.Year);
            int count = (int)cmd.ExecuteScalar();
            lbl_Taccidents.Text = count.ToString();

            string query2 = "SELECT SUM(Expenses) FROM Accident WHERE DATEPART(year, Date_Of_Acc) = @dateYear";
            SqlCommand cmd2 = new SqlCommand(query2, con);
            cmd2.Parameters.AddWithValue("@dateYear", date_year.Value.Year);
           object expenses = cmd2.ExecuteScalar();
            lbl_Texpenses.Text = expenses.ToString();

            if (con.State != ConnectionState.Closed)
            {
                con.Close();
            }
        }
        private void Draw_Chart()
        {
            Chart_Acc.Series.Clear();
            // Get the selected year from the DateTimePicker
            int selectedYear = date_year.Value.Year;

            // Define a SQL query to retrieve the data for the chart
            string query = "SELECT Brand, COUNT(*) AS Count " +
                           "FROM Accident a " +
                           "INNER JOIN Vehicle_Policy vp ON a.Policy_Number = vp.Policy_Number " +
                           $"WHERE YEAR(a.Date_Of_Acc) = {selectedYear} " +
                           "GROUP BY Brand";

            // Define a DataTable to hold the results of the query
            DataTable chartData = new DataTable();
            try
            {
                if (con.State != ConnectionState.Open)
                    con.Open();

                SqlDataAdapter adapter = new SqlDataAdapter(query, con);
                adapter.Fill(chartData);

                if (con.State == ConnectionState.Open)
                    con.Close();

                // Configure the chart control
                Chart_Acc.Series.Clear();
                Chart_Acc.Titles.Clear();
                Chart_Acc.Titles.Add("Accidents by Brand");

                Series series = Chart_Acc.Series.Add("Accidents");
                series.ChartType = SeriesChartType.Pie;
                series.IsValueShownAsLabel = true;

                // Add the data to the chart
                foreach (DataRow row in chartData.Rows)
                {
                    string brand = row["Brand"].ToString();
                    int count = Convert.ToInt32(row["Count"]);
                    series.Points.AddXY(brand, count);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An Error Occurred" + ex.Message);
            }
        }

        private void btn_print_Click(object sender, EventArgs e)
        {
            
        }

        private void Chart_Acc_Click(object sender, EventArgs e)
        {

        }

        private void txt_totalaccidents_TextChanged(object sender, EventArgs e)
        {

        }

        private void Acc_Evaluate_Load(object sender, EventArgs e)
        {
            if (con.State != ConnectionState.Open)
            {
                con.Open();
            }
            string query = "SELECT COUNT(*) FROM Accident WHERE DATEPART(year, Date_Of_Acc) = @dateYear";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@dateYear", date_year.Value.Year);
            int count = (int)cmd.ExecuteScalar();
            lbl_Taccidents.Text = count.ToString();

            string query2 = "SELECT SUM(Expenses) FROM Accident WHERE DATEPART(year, Date_Of_Acc) = @dateYear";
            SqlCommand cmd2 = new SqlCommand(query2, con);
            cmd2.Parameters.AddWithValue("@dateYear", date_year.Value.Year);
             object expenses =  cmd2.ExecuteScalar();
            lbl_Texpenses.Text = expenses.ToString();

            if (con.State != ConnectionState.Closed)
            {
                con.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Get the year from the DateTimePicker
            string year = date_year.Value.Year.ToString();

            // Save the chart as an image on the desktop with the year in the filename
            string imagePath = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory) + "\\Accidents_" + year + ".png";
            Chart_Acc.SaveImage(imagePath, ChartImageFormat.Png);

            MessageBox.Show("Chart saved as PNG on the desktop.");
        }
    }
    }

