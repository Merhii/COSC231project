﻿namespace Project_take1
{
    partial class Evaluate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.lbl_date = new System.Windows.Forms.Label();
            this.date_year = new System.Windows.Forms.DateTimePicker();
            this.chart_Evaluate = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.btn_print = new System.Windows.Forms.Button();
            this.lbl_income = new System.Windows.Forms.Label();
            this.lbl = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_profit = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.chart_Evaluate)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_date
            // 
            this.lbl_date.AutoSize = true;
            this.lbl_date.Location = new System.Drawing.Point(344, 571);
            this.lbl_date.Name = "lbl_date";
            this.lbl_date.Size = new System.Drawing.Size(68, 13);
            this.lbl_date.TabIndex = 5;
            this.lbl_date.Text = "Choose Year";
            // 
            // date_year
            // 
            this.date_year.CustomFormat = "yyyy";
            this.date_year.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.date_year.Location = new System.Drawing.Point(418, 568);
            this.date_year.Name = "date_year";
            this.date_year.ShowUpDown = true;
            this.date_year.Size = new System.Drawing.Size(49, 20);
            this.date_year.TabIndex = 4;
            this.date_year.ValueChanged += new System.EventHandler(this.date_year_ValueChanged);
            // 
            // chart_Evaluate
            // 
            this.chart_Evaluate.AccessibleDescription = "";
            this.chart_Evaluate.AccessibleName = "";
            chartArea1.Name = "ChartArea1";
            this.chart_Evaluate.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chart_Evaluate.Legends.Add(legend1);
            this.chart_Evaluate.Location = new System.Drawing.Point(-2, -3);
            this.chart_Evaluate.Name = "chart_Evaluate";
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            series1.XValueMember = "Brand";
            series1.YValueMembers = "Policy_Count";
            this.chart_Evaluate.Series.Add(series1);
            this.chart_Evaluate.Size = new System.Drawing.Size(1030, 517);
            this.chart_Evaluate.TabIndex = 3;
            this.chart_Evaluate.Click += new System.EventHandler(this.chart_Evaluate_Click);
            // 
            // btn_print
            // 
            this.btn_print.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.btn_print.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_print.Location = new System.Drawing.Point(471, 556);
            this.btn_print.Name = "btn_print";
            this.btn_print.Size = new System.Drawing.Size(124, 41);
            this.btn_print.TabIndex = 6;
            this.btn_print.Text = "Save ";
            this.btn_print.UseVisualStyleBackColor = false;
            this.btn_print.Click += new System.EventHandler(this.btn_print_Click);
            // 
            // lbl_income
            // 
            this.lbl_income.AutoSize = true;
            this.lbl_income.Location = new System.Drawing.Point(784, 530);
            this.lbl_income.Name = "lbl_income";
            this.lbl_income.Size = new System.Drawing.Size(0, 13);
            this.lbl_income.TabIndex = 9;
            // 
            // lbl
            // 
            this.lbl.AutoSize = true;
            this.lbl.Location = new System.Drawing.Point(745, 580);
            this.lbl.Name = "lbl";
            this.lbl.Size = new System.Drawing.Size(37, 13);
            this.lbl.TabIndex = 10;
            this.lbl.Text = "Profit :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(707, 530);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 13);
            this.label1.TabIndex = 11;
            this.label1.Text = "Total income:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // lbl_profit
            // 
            this.lbl_profit.AutoSize = true;
            this.lbl_profit.Location = new System.Drawing.Point(784, 580);
            this.lbl_profit.Name = "lbl_profit";
            this.lbl_profit.Size = new System.Drawing.Size(0, 13);
            this.lbl_profit.TabIndex = 15;
            // 
            // Evaluate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LavenderBlush;
            this.ClientSize = new System.Drawing.Size(1028, 642);
            this.Controls.Add(this.lbl_profit);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbl);
            this.Controls.Add(this.lbl_income);
            this.Controls.Add(this.btn_print);
            this.Controls.Add(this.lbl_date);
            this.Controls.Add(this.date_year);
            this.Controls.Add(this.chart_Evaluate);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Evaluate";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PolicyEevaluation ";
            this.Load += new System.EventHandler(this.Evaluate_Load);
            ((System.ComponentModel.ISupportInitialize)(this.chart_Evaluate)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_date;
        private System.Windows.Forms.DateTimePicker date_year;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart_Evaluate;
        private System.Windows.Forms.Button btn_print;
        private System.Windows.Forms.Label lbl_income;
        private System.Windows.Forms.Label lbl;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_profit;
    }
}