﻿namespace Project_take1
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelssn = new System.Windows.Forms.Label();
            this.txtssn = new System.Windows.Forms.TextBox();
            this.labelage = new System.Windows.Forms.Label();
            this.txtcity = new System.Windows.Forms.TextBox();
            this.labelcity = new System.Windows.Forms.Label();
            this.txtstr = new System.Windows.Forms.TextBox();
            this.labelstrt = new System.Windows.Forms.Label();
            this.txtname = new System.Windows.Forms.TextBox();
            this.labelname = new System.Windows.Forms.Label();
            this.Natonality = new System.Windows.Forms.Label();
            this.txtphone = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtemail = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtlnumber = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnadd = new System.Windows.Forms.Button();
            this.btnclear = new System.Windows.Forms.Button();
            this.btnload = new System.Windows.Forms.Button();
            this.date_of_birth = new System.Windows.Forms.DateTimePicker();
            this.comboboxcountry = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // labelssn
            // 
            this.labelssn.AutoSize = true;
            this.labelssn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelssn.Location = new System.Drawing.Point(62, 28);
            this.labelssn.Name = "labelssn";
            this.labelssn.Size = new System.Drawing.Size(80, 29);
            this.labelssn.TabIndex = 0;
            this.labelssn.Text = "SSN :";
            this.labelssn.Click += new System.EventHandler(this.labelssn_Click);
            // 
            // txtssn
            // 
            this.txtssn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtssn.Location = new System.Drawing.Point(68, 61);
            this.txtssn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtssn.Name = "txtssn";
            this.txtssn.Size = new System.Drawing.Size(228, 35);
            this.txtssn.TabIndex = 1;
            this.txtssn.TextChanged += new System.EventHandler(this.txtssn_TextChanged);
            // 
            // labelage
            // 
            this.labelage.AutoSize = true;
            this.labelage.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelage.Location = new System.Drawing.Point(62, 382);
            this.labelage.Name = "labelage";
            this.labelage.Size = new System.Drawing.Size(162, 29);
            this.labelage.TabIndex = 20;
            this.labelage.Text = "Date of birth:";
            // 
            // txtcity
            // 
            this.txtcity.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcity.Location = new System.Drawing.Point(68, 326);
            this.txtcity.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtcity.Name = "txtcity";
            this.txtcity.Size = new System.Drawing.Size(228, 35);
            this.txtcity.TabIndex = 23;
            // 
            // labelcity
            // 
            this.labelcity.AutoSize = true;
            this.labelcity.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelcity.Location = new System.Drawing.Point(62, 280);
            this.labelcity.Name = "labelcity";
            this.labelcity.Size = new System.Drawing.Size(71, 29);
            this.labelcity.TabIndex = 22;
            this.labelcity.Text = "City :";
            // 
            // txtstr
            // 
            this.txtstr.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtstr.Location = new System.Drawing.Point(432, 61);
            this.txtstr.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtstr.Name = "txtstr";
            this.txtstr.Size = new System.Drawing.Size(229, 35);
            this.txtstr.TabIndex = 25;
            // 
            // labelstrt
            // 
            this.labelstrt.AutoSize = true;
            this.labelstrt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelstrt.Location = new System.Drawing.Point(428, 28);
            this.labelstrt.Name = "labelstrt";
            this.labelstrt.Size = new System.Drawing.Size(97, 29);
            this.labelstrt.TabIndex = 24;
            this.labelstrt.Text = "Street :";
            // 
            // txtname
            // 
            this.txtname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtname.Location = new System.Drawing.Point(68, 139);
            this.txtname.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(228, 35);
            this.txtname.TabIndex = 27;
            // 
            // labelname
            // 
            this.labelname.AutoSize = true;
            this.labelname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelname.Location = new System.Drawing.Point(62, 105);
            this.labelname.Name = "labelname";
            this.labelname.Size = new System.Drawing.Size(96, 29);
            this.labelname.TabIndex = 26;
            this.labelname.Text = "Name :";
            // 
            // Natonality
            // 
            this.Natonality.AutoSize = true;
            this.Natonality.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Natonality.Location = new System.Drawing.Point(426, 280);
            this.Natonality.Name = "Natonality";
            this.Natonality.Size = new System.Drawing.Size(116, 29);
            this.Natonality.TabIndex = 28;
            this.Natonality.Text = "Country :";
            // 
            // txtphone
            // 
            this.txtphone.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtphone.Location = new System.Drawing.Point(433, 145);
            this.txtphone.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtphone.Name = "txtphone";
            this.txtphone.Size = new System.Drawing.Size(228, 35);
            this.txtphone.TabIndex = 31;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(429, 105);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(202, 29);
            this.label1.TabIndex = 30;
            this.label1.Text = "Phone Number :";
            // 
            // txtemail
            // 
            this.txtemail.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtemail.Location = new System.Drawing.Point(68, 219);
            this.txtemail.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(228, 35);
            this.txtemail.TabIndex = 33;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(62, 185);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(93, 29);
            this.label2.TabIndex = 32;
            this.label2.Text = "Email :";
            // 
            // txtlnumber
            // 
            this.txtlnumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtlnumber.Location = new System.Drawing.Point(435, 219);
            this.txtlnumber.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtlnumber.Name = "txtlnumber";
            this.txtlnumber.Size = new System.Drawing.Size(228, 35);
            this.txtlnumber.TabIndex = 35;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(429, 185);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(218, 29);
            this.label3.TabIndex = 34;
            this.label3.Text = "License Number :";
            // 
            // btnadd
            // 
            this.btnadd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.btnadd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnadd.ForeColor = System.Drawing.Color.White;
            this.btnadd.Location = new System.Drawing.Point(492, 434);
            this.btnadd.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnadd.Name = "btnadd";
            this.btnadd.Size = new System.Drawing.Size(141, 49);
            this.btnadd.TabIndex = 36;
            this.btnadd.Text = "ADD";
            this.btnadd.UseVisualStyleBackColor = false;
            this.btnadd.Click += new System.EventHandler(this.btnadd_Click);
            // 
            // btnclear
            // 
            this.btnclear.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.btnclear.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnclear.ForeColor = System.Drawing.Color.White;
            this.btnclear.Location = new System.Drawing.Point(492, 504);
            this.btnclear.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnclear.Name = "btnclear";
            this.btnclear.Size = new System.Drawing.Size(141, 49);
            this.btnclear.TabIndex = 37;
            this.btnclear.Text = "CLEAR";
            this.btnclear.UseVisualStyleBackColor = false;
            this.btnclear.Click += new System.EventHandler(this.btnclear_Click);
            // 
            // btnload
            // 
            this.btnload.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnload.Location = new System.Drawing.Point(504, 768);
            this.btnload.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnload.Name = "btnload";
            this.btnload.Size = new System.Drawing.Size(141, 71);
            this.btnload.TabIndex = 41;
            this.btnload.Text = "Load";
            this.btnload.UseVisualStyleBackColor = true;
            this.btnload.Click += new System.EventHandler(this.btnload_Click);
            // 
            // date_of_birth
            // 
            this.date_of_birth.Location = new System.Drawing.Point(68, 434);
            this.date_of_birth.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.date_of_birth.Name = "date_of_birth";
            this.date_of_birth.Size = new System.Drawing.Size(274, 26);
            this.date_of_birth.TabIndex = 43;
            // 
            // comboboxcountry
            // 
            this.comboboxcountry.FormattingEnabled = true;
            this.comboboxcountry.Location = new System.Drawing.Point(435, 335);
            this.comboboxcountry.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.comboboxcountry.Name = "comboboxcountry";
            this.comboboxcountry.Size = new System.Drawing.Size(226, 28);
            this.comboboxcountry.TabIndex = 44;
            this.comboboxcountry.SelectedIndexChanged += new System.EventHandler(this.comboboxcountry_SelectedIndexChanged);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LavenderBlush;
            this.ClientSize = new System.Drawing.Size(1107, 578);
            this.Controls.Add(this.comboboxcountry);
            this.Controls.Add(this.date_of_birth);
            this.Controls.Add(this.btnload);
            this.Controls.Add(this.btnclear);
            this.Controls.Add(this.btnadd);
            this.Controls.Add(this.txtlnumber);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtemail);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtphone);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Natonality);
            this.Controls.Add(this.txtname);
            this.Controls.Add(this.labelname);
            this.Controls.Add(this.txtstr);
            this.Controls.Add(this.labelstrt);
            this.Controls.Add(this.txtcity);
            this.Controls.Add(this.labelcity);
            this.Controls.Add(this.labelage);
            this.Controls.Add(this.txtssn);
            this.Controls.Add(this.labelssn);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MaximizeBox = false;
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add Client";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelssn;
        private System.Windows.Forms.TextBox txtssn;
        private System.Windows.Forms.Label labelage;
        private System.Windows.Forms.TextBox txtcity;
        private System.Windows.Forms.Label labelcity;
        private System.Windows.Forms.TextBox txtstr;
        private System.Windows.Forms.Label labelstrt;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.Label labelname;
        private System.Windows.Forms.Label Natonality;
        private System.Windows.Forms.TextBox txtphone;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtemail;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtlnumber;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnadd;
        private System.Windows.Forms.Button btnclear;
        private System.Windows.Forms.Button btnload;
        private System.Windows.Forms.DateTimePicker date_of_birth;
        private System.Windows.Forms.ComboBox comboboxcountry;
    }
}