﻿namespace Project_take1
{
    partial class dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(dashboard));
            this.pannelside = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btn_ViewAs = new System.Windows.Forms.Button();
            this.btn_editAs = new System.Windows.Forms.Button();
            this.btn_As = new System.Windows.Forms.Button();
            this.btnemployee = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btn_ViewEmpl = new System.Windows.Forms.Button();
            this.btnaddEmp = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.buttonSignOut = new System.Windows.Forms.Button();
            this.buttonClient = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.mainpannel = new System.Windows.Forms.Panel();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.userControlRemoveAs1 = new Project_take1.UserControlRemoveAs();
            this.userControlEditAs1 = new Project_take1.UserControlEditAs();
            this.userControlViewEmpl1 = new Project_take1.UserControlViewEmpl();
            this.userControlEmp2 = new Project_take1.UserControlEmp();
            this.uCclient1 = new Project_take1.UCclient();
            this.userControl41 = new Project_take1.UserControl4();
            this.pannelside.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.mainpannel.SuspendLayout();
            this.SuspendLayout();
            // 
            // pannelside
            // 
            this.pannelside.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.pannelside.Controls.Add(this.panel3);
            this.pannelside.Controls.Add(this.btn_As);
            this.pannelside.Controls.Add(this.btnemployee);
            this.pannelside.Controls.Add(this.panel2);
            this.pannelside.Controls.Add(this.panel1);
            this.pannelside.Controls.Add(this.buttonSignOut);
            this.pannelside.Controls.Add(this.buttonClient);
            this.pannelside.Controls.Add(this.button1);
            this.pannelside.Location = new System.Drawing.Point(0, -2);
            this.pannelside.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pannelside.Name = "pannelside";
            this.pannelside.Size = new System.Drawing.Size(201, 612);
            this.pannelside.TabIndex = 0;
            this.pannelside.TabStop = true;
            this.pannelside.Paint += new System.Windows.Forms.PaintEventHandler(this.pannelside_Paint);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.btn_ViewAs);
            this.panel3.Controls.Add(this.btn_editAs);
            this.panel3.Location = new System.Drawing.Point(-1, 410);
            this.panel3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(194, 114);
            this.panel3.TabIndex = 47;
            // 
            // btn_ViewAs
            // 
            this.btn_ViewAs.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.btn_ViewAs.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ViewAs.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ViewAs.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_ViewAs.Location = new System.Drawing.Point(-11, 56);
            this.btn_ViewAs.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_ViewAs.Name = "btn_ViewAs";
            this.btn_ViewAs.Size = new System.Drawing.Size(213, 55);
            this.btn_ViewAs.TabIndex = 43;
            this.btn_ViewAs.Text = "View Specialists";
            this.btn_ViewAs.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.btn_ViewAs.UseVisualStyleBackColor = false;
            this.btn_ViewAs.Click += new System.EventHandler(this.btn_ViewAs_Click);
            // 
            // btn_editAs
            // 
            this.btn_editAs.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_editAs.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_editAs.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_editAs.Location = new System.Drawing.Point(-8, 2);
            this.btn_editAs.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_editAs.Name = "btn_editAs";
            this.btn_editAs.Size = new System.Drawing.Size(209, 56);
            this.btn_editAs.TabIndex = 7;
            this.btn_editAs.Text = "Edit Specialists";
            this.btn_editAs.UseVisualStyleBackColor = true;
            this.btn_editAs.Click += new System.EventHandler(this.btn_editAs_Click);
            // 
            // btn_As
            // 
            this.btn_As.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.btn_As.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_As.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_As.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_As.Location = new System.Drawing.Point(-11, 360);
            this.btn_As.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_As.Name = "btn_As";
            this.btn_As.Size = new System.Drawing.Size(212, 51);
            this.btn_As.TabIndex = 46;
            this.btn_As.Text = "Specialists";
            this.btn_As.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.btn_As.UseVisualStyleBackColor = false;
            this.btn_As.Click += new System.EventHandler(this.btn_As_Click);
            // 
            // btnemployee
            // 
            this.btnemployee.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.btnemployee.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnemployee.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnemployee.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnemployee.Location = new System.Drawing.Point(-12, 185);
            this.btnemployee.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnemployee.Name = "btnemployee";
            this.btnemployee.Size = new System.Drawing.Size(209, 51);
            this.btnemployee.TabIndex = 45;
            this.btnemployee.Text = " Employees";
            this.btnemployee.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.btnemployee.UseVisualStyleBackColor = false;
            this.btnemployee.Click += new System.EventHandler(this.button2_Click_2);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btn_ViewEmpl);
            this.panel2.Controls.Add(this.btnaddEmp);
            this.panel2.Location = new System.Drawing.Point(0, 235);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(194, 108);
            this.panel2.TabIndex = 44;
            // 
            // btn_ViewEmpl
            // 
            this.btn_ViewEmpl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.btn_ViewEmpl.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ViewEmpl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ViewEmpl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_ViewEmpl.Location = new System.Drawing.Point(-12, 52);
            this.btn_ViewEmpl.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_ViewEmpl.Name = "btn_ViewEmpl";
            this.btn_ViewEmpl.Size = new System.Drawing.Size(212, 55);
            this.btn_ViewEmpl.TabIndex = 43;
            this.btn_ViewEmpl.Text = "View Employees";
            this.btn_ViewEmpl.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.btn_ViewEmpl.UseVisualStyleBackColor = false;
            this.btn_ViewEmpl.Click += new System.EventHandler(this.btn_ViewEmpl_Click);
            // 
            // btnaddEmp
            // 
            this.btnaddEmp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnaddEmp.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnaddEmp.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnaddEmp.Location = new System.Drawing.Point(-10, 2);
            this.btnaddEmp.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnaddEmp.Name = "btnaddEmp";
            this.btnaddEmp.Size = new System.Drawing.Size(207, 56);
            this.btnaddEmp.TabIndex = 7;
            this.btnaddEmp.Text = "Edit Employees";
            this.btnaddEmp.UseVisualStyleBackColor = true;
            this.btnaddEmp.Click += new System.EventHandler(this.btnEmp_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LavenderBlush;
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(197, 85);
            this.panel1.TabIndex = 2;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // buttonSignOut
            // 
            this.buttonSignOut.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSignOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSignOut.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.buttonSignOut.Location = new System.Drawing.Point(-12, 529);
            this.buttonSignOut.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonSignOut.Name = "buttonSignOut";
            this.buttonSignOut.Size = new System.Drawing.Size(228, 55);
            this.buttonSignOut.TabIndex = 6;
            this.buttonSignOut.Text = "Sign Out";
            this.buttonSignOut.UseVisualStyleBackColor = true;
            this.buttonSignOut.Click += new System.EventHandler(this.buttonSignOut_Click);
            // 
            // buttonClient
            // 
            this.buttonClient.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonClient.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonClient.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.buttonClient.Location = new System.Drawing.Point(-16, 134);
            this.buttonClient.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonClient.Name = "buttonClient";
            this.buttonClient.Size = new System.Drawing.Size(228, 51);
            this.buttonClient.TabIndex = 2;
            this.buttonClient.Text = "Client";
            this.buttonClient.UseVisualStyleBackColor = true;
            this.buttonClient.Click += new System.EventHandler(this.buttonClient_Click);
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button1.Location = new System.Drawing.Point(-12, 82);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(228, 58);
            this.button1.TabIndex = 1;
            this.button1.Text = "Home";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // mainpannel
            // 
            this.mainpannel.Controls.Add(this.userControlRemoveAs1);
            this.mainpannel.Controls.Add(this.userControlEditAs1);
            this.mainpannel.Controls.Add(this.userControlViewEmpl1);
            this.mainpannel.Controls.Add(this.userControlEmp2);
            this.mainpannel.Controls.Add(this.uCclient1);
            this.mainpannel.Controls.Add(this.userControl41);
            this.mainpannel.Dock = System.Windows.Forms.DockStyle.Right;
            this.mainpannel.Location = new System.Drawing.Point(191, 0);
            this.mainpannel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.mainpannel.Name = "mainpannel";
            this.mainpannel.Size = new System.Drawing.Size(915, 578);
            this.mainpannel.TabIndex = 1;
            // 
            // userControlRemoveAs1
            // 
            this.userControlRemoveAs1.BackColor = System.Drawing.Color.LavenderBlush;
            this.userControlRemoveAs1.Location = new System.Drawing.Point(0, -1);
            this.userControlRemoveAs1.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.userControlRemoveAs1.Name = "userControlRemoveAs1";
            this.userControlRemoveAs1.Size = new System.Drawing.Size(915, 594);
            this.userControlRemoveAs1.TabIndex = 8;
            this.userControlRemoveAs1.Load += new System.EventHandler(this.userControlRemoveAs1_Load);
            // 
            // userControlEditAs1
            // 
            this.userControlEditAs1.BackColor = System.Drawing.Color.LavenderBlush;
            this.userControlEditAs1.Location = new System.Drawing.Point(0, -12);
            this.userControlEditAs1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.userControlEditAs1.Name = "userControlEditAs1";
            this.userControlEditAs1.Size = new System.Drawing.Size(915, 594);
            this.userControlEditAs1.TabIndex = 7;
            // 
            // userControlViewEmpl1
            // 
            this.userControlViewEmpl1.BackColor = System.Drawing.Color.LavenderBlush;
            this.userControlViewEmpl1.Location = new System.Drawing.Point(3, -1);
            this.userControlViewEmpl1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.userControlViewEmpl1.Name = "userControlViewEmpl1";
            this.userControlViewEmpl1.Size = new System.Drawing.Size(915, 594);
            this.userControlViewEmpl1.TabIndex = 6;
            this.userControlViewEmpl1.Load += new System.EventHandler(this.userControlViewEmpl1_Load);
            // 
            // userControlEmp2
            // 
            this.userControlEmp2.BackColor = System.Drawing.Color.LavenderBlush;
            this.userControlEmp2.Location = new System.Drawing.Point(2, -1);
            this.userControlEmp2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.userControlEmp2.Name = "userControlEmp2";
            this.userControlEmp2.Size = new System.Drawing.Size(915, 594);
            this.userControlEmp2.TabIndex = 5;
            // 
            // uCclient1
            // 
            this.uCclient1.BackColor = System.Drawing.Color.LavenderBlush;
            this.uCclient1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("uCclient1.BackgroundImage")));
            this.uCclient1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.uCclient1.Location = new System.Drawing.Point(0, -2);
            this.uCclient1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.uCclient1.Name = "uCclient1";
            this.uCclient1.Size = new System.Drawing.Size(915, 594);
            this.uCclient1.TabIndex = 4;
            this.uCclient1.Load += new System.EventHandler(this.uCclient1_Load_1);
            // 
            // userControl41
            // 
            this.userControl41.BackColor = System.Drawing.Color.LavenderBlush;
            this.userControl41.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("userControl41.BackgroundImage")));
            this.userControl41.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.userControl41.Location = new System.Drawing.Point(3, -2);
            this.userControl41.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.userControl41.Name = "userControl41";
            this.userControl41.Size = new System.Drawing.Size(915, 594);
            this.userControl41.TabIndex = 3;
            this.userControl41.Load += new System.EventHandler(this.userControl41_Load_2);
            // 
            // dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LavenderBlush;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(1106, 578);
            this.Controls.Add(this.mainpannel);
            this.Controls.Add(this.pannelside);
            this.DoubleBuffered = true;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1128, 634);
            this.Name = "dashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Dashboard";
            this.Load += new System.EventHandler(this.dashboard_Load);
            this.pannelside.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.mainpannel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pannelside;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button buttonSignOut;
        private System.Windows.Forms.Button buttonClient;
        private System.Windows.Forms.Panel mainpannel;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private UCclient uCclient1;
        private UserControl4 userControl41;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnaddEmp;
        private UserControlEmp userControlEmp1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btn_ViewEmpl;
        private System.Windows.Forms.Button btnemployee;
        private UserControlEmp userControlEmp2;
        private UserControlViewEmpl userControlViewEmpl1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btn_ViewAs;
        private System.Windows.Forms.Button btn_editAs;
        private System.Windows.Forms.Button btn_As;
        private UserControlEditAs userControlEditAs1;
        private UserControlRemoveAs userControlRemoveAs1;
    }
}