﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_take1
{
    public partial class Accident : Form
    {
        SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["myDB"].ToString());

        public Accident()
        {
            InitializeComponent();
            string query = "select * from Accident";
            SqlDataAdapter adapter = new SqlDataAdapter(query, con);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            grd_Accident.DataSource = dt;

        }

        private void Accident_Load(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void VIEW_Click(object sender, EventArgs e)
        {
            string query = "select * from Accident";
            SqlDataAdapter adapter = new SqlDataAdapter(query, con);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            grd_Accident.DataSource = dt;
        }

        private void btn_addAccident_Click(object sender, EventArgs e)
        {

            //query to get the plate number from policy number
            string query2 = "SELECT Plate_number From Vehicle_Policy where Policy_Number = @Policy_Number";
            SqlCommand Scmd = new SqlCommand(query2, con);
            string Plate_number = "";
            try
            {

                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }
                Scmd.Parameters.AddWithValue("@Policy_Number", int.Parse(txt_PolicyNumber.Text));

                object result = Scmd.ExecuteScalar();
                Plate_number = (string)result;

                txt_ASID.Text = "";
                txt_ClientID.Text = "";
                txt_Expenses.Text = "";
                txt_Place.Text = "";
                txt_PolicyNumber.Text = "";
                Date_of_Accident.Value = DateTime.Today;
                rd_no.Checked = rd_yes.Checked = false;

                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            catch (Exception ex)
            {
            }
            //query to insert new accident
            try
            {
                string query1 = "INSERT INTO Accident VALUES (@C_ID, @AS_ID, @Plate_Number, @Policy_Number, @Place, @Date_Of_Acc, @Approval, @Expenses); SELECT SCOPE_IDENTITY()";
                SqlCommand cmd = new SqlCommand(query1, con);
                cmd.Parameters.AddWithValue("@C_ID", int.Parse(txt_ClientID.Text));
                cmd.Parameters.AddWithValue("@AS_ID", int.Parse(txt_ASID.Text));
                cmd.Parameters.AddWithValue("@Date_Of_Acc", Date_of_Accident.Value);
                cmd.Parameters.AddWithValue("@Place", txt_Place.Text);
                cmd.Parameters.AddWithValue("@Expenses", int.Parse(txt_Expenses.Text));
                cmd.Parameters.AddWithValue("@Plate_Number", Plate_number);
                cmd.Parameters.AddWithValue("@Policy_Number", int.Parse(txt_PolicyNumber.Text));

                if (rd_no.Checked)
                {
                    cmd.Parameters.AddWithValue("@Approval", 0);

                }
                if (rd_yes.Checked)
                {
                    cmd.Parameters.AddWithValue("@Approval", 1);
                }


                try
                {
                    if (con.State != ConnectionState.Open)
                    {
                        con.Open();
                    }
                    cmd.ExecuteNonQuery();
                   
                    MessageBox.Show("Accident added successfully.");

                    if (con.State == ConnectionState.Open)
                    {
                        con.Close();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: Please Check Entered Information");

                }
                if (rd_yes.Checked)
                {
                    string query5 = "Select Active From Vehicle_Policy where Policy_Number = @Policy_Number";
                    SqlCommand cmdA = new SqlCommand(query5, con);
                    int Active = 0;
                    try
                    {
                        if (con.State != ConnectionState.Open)
                        {
                            con.Open();
                        }
                        cmdA.Parameters.AddWithValue("@Policy_Number", int.Parse(txt_PolicyNumber.Text));

                        object result_Active = cmdA.ExecuteScalar();
                        Active = Convert.ToInt32(result_Active);

                        if (con.State == ConnectionState.Open)
                        {
                            con.Close();
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("An error occurred in query5: " + ex.Message);

                    }
                    if (Active == 1)
                    {
                        //queries to update the paid coverage after adding accidents
                        string query3 = "SELECT Paid_From_Coverage From Vehicle_Policy where Policy_Number = @Policy_Number";
                        SqlCommand cmdc = new SqlCommand(query3, con);
                        int old_paid = 0;
                        try
                        {
                            if (con.State != ConnectionState.Open)
                            {
                                con.Open();
                            }
                            cmdc.Parameters.AddWithValue("@Policy_Number", int.Parse(txt_PolicyNumber.Text));

                            object result_paid = cmdc.ExecuteScalar();
                            old_paid = Convert.ToInt32(result_paid);

                            if (con.State == ConnectionState.Open)
                            {
                                con.Close();
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("An error occurred in query3: " + ex.Message);

                        }
                        string query4 = "Update Vehicle_Policy Set Paid_From_Coverage = @Paid_Coverage where Policy_Number = @Policy_number";
                        SqlCommand cmdU = new SqlCommand(query4, con);

                        try
                        {
                            if (con.State != ConnectionState.Open)
                            {
                                con.Open();
                            }
                            cmdU.Parameters.AddWithValue("@Paid_Coverage", old_paid + int.Parse(txt_Expenses.Text));
                            cmdU.Parameters.AddWithValue("@Policy_Number", int.Parse(txt_PolicyNumber.Text));
                            cmdU.ExecuteNonQuery();

                            if (con.State == ConnectionState.Open)
                            {
                                con.Close();
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("An error occurred in query4: " + ex.Message);

                        }
                    }
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("Please fill in the informaion");
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txt_date_TextChanged(object sender, EventArgs e)
        {

        }

        private void Date_of_Accident_ValueChanged(object sender, EventArgs e)
        {

        }

        private void txt_PolicyNumber_TextChanged(object sender, EventArgs e)
        {

        }

        private void lbl_PolicyNumber_Click(object sender, EventArgs e)
        {

        }

        private void lbl_Date_Click(object sender, EventArgs e)
        {

        }

        private void txt_Expenses_TextChanged(object sender, EventArgs e)
        {

        }

        private void chk_yes_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void chk_no_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void lbl_Acceptance_Click(object sender, EventArgs e)
        {

        }

        private void rd_yes_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void grd_Accident_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
    
        }
    }
}
