﻿namespace Project_take1
{
    partial class btn_ViewForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grid_ClientView = new System.Windows.Forms.DataGridView();
            this.btn_ViewClients = new System.Windows.Forms.Button();
            this.txt_search = new System.Windows.Forms.TextBox();
            this.lbl_search = new System.Windows.Forms.Label();
            this.datagridviewPolicy = new System.Windows.Forms.DataGridView();
            this.buttonviewPolicy = new System.Windows.Forms.Button();
            this.txt_viewPolicy = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btneditc = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btneditp = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.grid_ClientView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.datagridviewPolicy)).BeginInit();
            this.SuspendLayout();
            // 
            // grid_ClientView
            // 
            this.grid_ClientView.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.grid_ClientView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grid_ClientView.Location = new System.Drawing.Point(28, 112);
            this.grid_ClientView.Name = "grid_ClientView";
            this.grid_ClientView.RowHeadersWidth = 51;
            this.grid_ClientView.Size = new System.Drawing.Size(448, 294);
            this.grid_ClientView.TabIndex = 0;
            this.grid_ClientView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // btn_ViewClients
            // 
            this.btn_ViewClients.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.btn_ViewClients.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ViewClients.ForeColor = System.Drawing.Color.White;
            this.btn_ViewClients.Location = new System.Drawing.Point(236, 72);
            this.btn_ViewClients.Name = "btn_ViewClients";
            this.btn_ViewClients.Size = new System.Drawing.Size(93, 33);
            this.btn_ViewClients.TabIndex = 1;
            this.btn_ViewClients.Text = "View Clients";
            this.btn_ViewClients.UseVisualStyleBackColor = false;
            this.btn_ViewClients.Click += new System.EventHandler(this.ViewClients_Click);
            // 
            // txt_search
            // 
            this.txt_search.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_search.Location = new System.Drawing.Point(28, 72);
            this.txt_search.Name = "txt_search";
            this.txt_search.Size = new System.Drawing.Size(181, 35);
            this.txt_search.TabIndex = 2;
            this.txt_search.TextChanged += new System.EventHandler(this.txt_search_TextChanged);
            // 
            // lbl_search
            // 
            this.lbl_search.AutoSize = true;
            this.lbl_search.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_search.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.lbl_search.Location = new System.Drawing.Point(23, 26);
            this.lbl_search.Name = "lbl_search";
            this.lbl_search.Size = new System.Drawing.Size(186, 29);
            this.lbl_search.TabIndex = 3;
            this.lbl_search.Text = "Search by name";
            // 
            // datagridviewPolicy
            // 
            this.datagridviewPolicy.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.datagridviewPolicy.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datagridviewPolicy.Location = new System.Drawing.Point(536, 112);
            this.datagridviewPolicy.Name = "datagridviewPolicy";
            this.datagridviewPolicy.RowHeadersWidth = 51;
            this.datagridviewPolicy.Size = new System.Drawing.Size(432, 294);
            this.datagridviewPolicy.TabIndex = 4;
            this.datagridviewPolicy.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.datagridviewPolicy_CellContentClick);
            // 
            // buttonviewPolicy
            // 
            this.buttonviewPolicy.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.buttonviewPolicy.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonviewPolicy.ForeColor = System.Drawing.Color.White;
            this.buttonviewPolicy.Location = new System.Drawing.Point(742, 72);
            this.buttonviewPolicy.Name = "buttonviewPolicy";
            this.buttonviewPolicy.Size = new System.Drawing.Size(122, 33);
            this.buttonviewPolicy.TabIndex = 5;
            this.buttonviewPolicy.Text = "View Policies";
            this.buttonviewPolicy.UseVisualStyleBackColor = false;
            this.buttonviewPolicy.Click += new System.EventHandler(this.buttonviewPolicy_Click);
            // 
            // txt_viewPolicy
            // 
            this.txt_viewPolicy.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_viewPolicy.Location = new System.Drawing.Point(536, 72);
            this.txt_viewPolicy.Name = "txt_viewPolicy";
            this.txt_viewPolicy.Size = new System.Drawing.Size(181, 35);
            this.txt_viewPolicy.TabIndex = 6;
            this.txt_viewPolicy.TextChanged += new System.EventHandler(this.txt_viewPolicy_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.label1.Location = new System.Drawing.Point(530, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(217, 29);
            this.label1.TabIndex = 7;
            this.label1.Text = "Search by Client ID";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // btneditc
            // 
            this.btneditc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.btneditc.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btneditc.ForeColor = System.Drawing.Color.White;
            this.btneditc.Location = new System.Drawing.Point(168, 437);
            this.btneditc.Name = "btneditc";
            this.btneditc.Size = new System.Drawing.Size(93, 33);
            this.btneditc.TabIndex = 8;
            this.btneditc.Text = "Click Here";
            this.btneditc.UseVisualStyleBackColor = false;
            this.btneditc.Click += new System.EventHandler(this.btnedit_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.label2.Location = new System.Drawing.Point(132, 415);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(207, 20);
            this.label2.TabIndex = 9;
            this.label2.Text = "Edit Client\'s Information ";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.label3.Location = new System.Drawing.Point(675, 415);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(207, 20);
            this.label3.TabIndex = 11;
            this.label3.Text = "Edit Policy\'s Information ";
            // 
            // btneditp
            // 
            this.btneditp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.btneditp.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btneditp.ForeColor = System.Drawing.Color.White;
            this.btneditp.Location = new System.Drawing.Point(711, 437);
            this.btneditp.Name = "btneditp";
            this.btneditp.Size = new System.Drawing.Size(93, 33);
            this.btneditp.TabIndex = 10;
            this.btneditp.Text = "Click Here";
            this.btneditp.UseVisualStyleBackColor = false;
            this.btneditp.Click += new System.EventHandler(this.btneditp_Click);
            // 
            // btn_ViewForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LavenderBlush;
            this.ClientSize = new System.Drawing.Size(1000, 487);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btneditp);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btneditc);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_viewPolicy);
            this.Controls.Add(this.buttonviewPolicy);
            this.Controls.Add(this.datagridviewPolicy);
            this.Controls.Add(this.lbl_search);
            this.Controls.Add(this.txt_search);
            this.Controls.Add(this.btn_ViewClients);
            this.Controls.Add(this.grid_ClientView);
            this.MaximizeBox = false;
            this.Name = "btn_ViewForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ViewForm";
            this.Load += new System.EventHandler(this.btn_ViewForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.grid_ClientView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.datagridviewPolicy)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView grid_ClientView;
        private System.Windows.Forms.Button btn_ViewClients;
        private System.Windows.Forms.TextBox txt_search;
        private System.Windows.Forms.Label lbl_search;
        private System.Windows.Forms.DataGridView datagridviewPolicy;
        private System.Windows.Forms.Button buttonviewPolicy;
        private System.Windows.Forms.TextBox txt_viewPolicy;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btneditc;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btneditp;
    }
}