﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_take1
{
    public partial class UserControlViewEmp : UserControl
    {
        public UserControlViewEmp()
        {
            InitializeComponent();
        }
    }
}
