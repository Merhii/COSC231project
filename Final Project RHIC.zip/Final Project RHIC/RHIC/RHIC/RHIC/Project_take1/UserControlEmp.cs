﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_take1
{
   
    public partial class UserControlEmp : UserControl
    {

        public UserControlEmp()
        {
            InitializeComponent();
            btn_Removee.Hide();
            txt_IDe.Hide();
            labelID.Hide();
            btn_Adde.Hide();
            txt_emaile.Hide();
            txt_Namee.Hide();
            txt_Password.Hide();
            labelpass.Hide();
            label2.Hide();
            label3.Hide();
            label4.Hide();
            rd_manager0.Hide();
            rd_manager1.Hide();
        }

     

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
          
               

            
        }

        private void UCE_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void rd_Add_CheckedChanged(object sender, EventArgs e)
        {
           
                

        }

        private void txt_Namee_TextChanged(object sender, EventArgs e)
        {

        }

        private void UserControlEmp_Load_1(object sender, EventArgs e)
        {

        }

        private void rd_Add_CheckedChanged_1(object sender, EventArgs e)
        {

            btn_Removee.Hide();
         labelID.Hide();
            txt_IDe.Hide();
            labelpass.Show();
            label2.Show();
            label3.Show();
            label4.Show();
            txt_emaile.Show();
            txt_Namee.Show();
            txt_Password.Show();
            rd_manager1.Show();
            rd_manager0.Show();
            btn_Adde.Show();
        }

        private void rd_Remove_CheckedChanged(object sender, EventArgs e)
        {

            btn_Adde.Hide();
            txt_emaile.Hide();
            txt_Namee.Hide();
            txt_Password.Hide();
            labelpass.Hide();
            label2.Hide();
            label3.Hide();
            label4.Hide();
            rd_manager0.Hide();
            rd_manager1.Hide();

            btn_Adde.Hide();
            labelID.Show();
            txt_IDe.Show();
            btn_Removee.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
        }

        private void btn_Removee_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["myDB"].ToString());
            int ID = 0;
            try
            { 
                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }
                var confirmResult = MessageBox.Show("Are You Sure You Want to Remove the Employee ?",
                                     "Confirm Removal",
                                     MessageBoxButtons.YesNo);

                string SelectEID = "SELECT E_ID FROM Employee WHERE E_ID = @ID";
                SqlCommand cmds = new SqlCommand(SelectEID, con);
                cmds.Parameters.AddWithValue("@ID", int.Parse(txt_IDe.Text));
                object result = cmds.ExecuteScalar();

                if (result != null)
                    ID = int.Parse(result.ToString());
                else
                    throw new Exception("The ID You Entered Doesn't Exist");

                if (confirmResult == DialogResult.Yes)
                {

                    string DeleteQ = "Delete FROM Employee where E_ID=@ID";
                    SqlCommand cmd = new SqlCommand(DeleteQ, con);
                    cmd.Parameters.AddWithValue("@ID", int.Parse(txt_IDe.Text));
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Employee Removed Successfully");
                    txt_IDe.Text = "";
                }

                

                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            catch (Exception msg)
            {

                MessageBox.Show("Please Enter Correct ID to Remove The Corresponding Employee");
            }
        }

        private void btn_Adde_Click_1(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["myDB"].ToString());

            try
            {

                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }

                string query1 = "INSERT INTO Employee VALUES (@Name, @Email, @Password, @Manager); SELECT SCOPE_IDENTITY()";
                SqlCommand cmd = new SqlCommand(query1, con);
                cmd.Parameters.AddWithValue("@Name", txt_Namee.Text);
                cmd.Parameters.AddWithValue("@Email", txt_emaile.Text);
                cmd.Parameters.AddWithValue("@Password", txt_Password.Text);
                if (rd_manager0.Checked)
                {
                    cmd.Parameters.AddWithValue("@Manager", 1);
                }
                else if (rd_manager1.Checked)
                {
                    cmd.Parameters.AddWithValue("@Manager", 0);
                }
                cmd.ExecuteNonQuery();
                MessageBox.Show("Employee Added Successfully");
                txt_emaile.Text = "";
                txt_Namee.Text = "";
                txt_Password.Text = "";
                rd_manager0.Checked = false;
                rd_manager1.Checked = false;

                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            catch (Exception msg)
            {

                MessageBox.Show("Please Enter Correct Information");
            }

    }

        private void btn_ViewEmpl_Click(object sender, EventArgs e)
        {

        }
    }
}
