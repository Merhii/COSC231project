﻿namespace Project_take1
{
    partial class UserControlViewEmpl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UserControlViewEmpl));
            this.btn_LoadEmp = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridLoadEmp = new System.Windows.Forms.DataGridView();
            this.txt_Empsearch = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridLoadEmp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_LoadEmp
            // 
            this.btn_LoadEmp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.btn_LoadEmp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_LoadEmp.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_LoadEmp.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_LoadEmp.Location = new System.Drawing.Point(435, 149);
            this.btn_LoadEmp.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_LoadEmp.Name = "btn_LoadEmp";
            this.btn_LoadEmp.Size = new System.Drawing.Size(201, 44);
            this.btn_LoadEmp.TabIndex = 54;
            this.btn_LoadEmp.Text = "Load";
            this.btn_LoadEmp.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.btn_LoadEmp.UseVisualStyleBackColor = false;
            this.btn_LoadEmp.Click += new System.EventHandler(this.btn_LoadEmp_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Showcard Gothic", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.label1.Location = new System.Drawing.Point(161, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(426, 33);
            this.label1.TabIndex = 52;
            this.label1.Text = "Employees Of Our Company";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // dataGridLoadEmp
            // 
            this.dataGridLoadEmp.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.dataGridLoadEmp.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridLoadEmp.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.dataGridLoadEmp.Location = new System.Drawing.Point(61, 136);
            this.dataGridLoadEmp.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataGridLoadEmp.Name = "dataGridLoadEmp";
            this.dataGridLoadEmp.RowHeadersWidth = 62;
            this.dataGridLoadEmp.RowTemplate.Height = 28;
            this.dataGridLoadEmp.Size = new System.Drawing.Size(356, 322);
            this.dataGridLoadEmp.TabIndex = 51;
            this.dataGridLoadEmp.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridLoadEmp_CellContentClick);
            // 
            // txt_Empsearch
            // 
            this.txt_Empsearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Empsearch.Location = new System.Drawing.Point(61, 99);
            this.txt_Empsearch.Name = "txt_Empsearch";
            this.txt_Empsearch.Size = new System.Drawing.Size(262, 32);
            this.txt_Empsearch.TabIndex = 55;
            this.txt_Empsearch.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(329, 105);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(41, 24);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 57;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click_1);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LavenderBlush;
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel1.Location = new System.Drawing.Point(449, 207);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(317, 256);
            this.panel1.TabIndex = 53;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // UserControlViewEmpl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LavenderBlush;
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.txt_Empsearch);
            this.Controls.Add(this.btn_LoadEmp);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridLoadEmp);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "UserControlViewEmpl";
            this.Size = new System.Drawing.Size(813, 475);
            this.Load += new System.EventHandler(this.UserControlViewEmpl_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridLoadEmp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_LoadEmp;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridLoadEmp;
        private System.Windows.Forms.TextBox txt_Empsearch;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}
