﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Project_take1
{

    public partial class frmReg : Form
    {
        public static int EmployeeID;
        public static string EmployeeName="";
        public static bool Ismanager;
        SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["myDB"].ToString());


        public frmReg()
        {
            InitializeComponent();
            if (con.State != ConnectionState.Open)
                con.Open();
            SqlCommand cmd = new SqlCommand("UPDATE Vehicle_Policy SET Active = 0 WHERE Expiry_Date < @CurrentDate", con);
            cmd.Parameters.AddWithValue("@CurrentDate", DateTime.Now);
            cmd.ExecuteNonQuery();
            if (con.State == ConnectionState.Open)
                con.Close();
        }
       
       
       
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txt_ID_TextChanged(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btn_login_Click(object sender, EventArgs e)
        {

            
            SqlCommand cmd2 = new SqlCommand("SELECT  Manager FROM Employee WHERE E_ID=@ID", con);
            SqlCommand cmd = new SqlCommand("SELECT * FROM Employee WHERE E_ID=@ID AND  Password=@Password ", con);
            try
            {
                cmd.Parameters.AddWithValue("@ID", int.Parse(txtid.Text));
                cmd.Parameters.AddWithValue("@Password", txtpass.Text);
                cmd2.Parameters.AddWithValue("@ID", int.Parse(txtid.Text));

                if (con.State != ConnectionState.Open)
                    con.Open();

                

                //  Console.WriteLine(result2.ToString());

                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.Read() == true)
                {
                    dr.Close();

                    SqlCommand cmdn = new SqlCommand("SELECT Name FROM Employee WHERE E_ID = @ID", con);
                    cmdn.Parameters.AddWithValue("@ID", int.Parse(txtid.Text));
                    frmReg.EmployeeID = int.Parse(txtid.Text);
                    object result = cmdn.ExecuteScalar();
                    frmReg.EmployeeName = result.ToString();
                    object result2 = cmd2.ExecuteScalar();
                    frmReg.Ismanager = bool.Parse(result2.ToString());
                    //  Console.WriteLine(frmReg.EmployeeName);
                    new dashboard().Show();
                    this.Hide();

                }
                else
                {
                    MessageBox.Show("Please enter Correct ID and Password");
                    txtid.Text = "";
                    txtpass.Text = "";
                }
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show("Enter ID and Password");
            }
        }
        

private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkbxshow.Checked)
            {
                txtpass.PasswordChar = '\0';
            }
            else
            {
                txtpass.PasswordChar = '*';
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        { 
            txtid.Text = "";
            txtpass.Text = "";
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var confirmResult = MessageBox.Show(" Are you sure you want to Exit? ",
                                  "Confirm Exit",
                                  MessageBoxButtons.YesNo);
            if (confirmResult == DialogResult.Yes)
            { 
                this.Hide();
                Close();
            }
            
        }

        private void txtid_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}