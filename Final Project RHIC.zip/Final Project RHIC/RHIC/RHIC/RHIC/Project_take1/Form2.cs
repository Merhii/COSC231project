﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Net.Sockets;
using System.Globalization;
using System.Collections;

namespace Project_take1
{
    
    public partial class Form2 : Form
    {
        SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["myDB"].ToString());
        List<string> cultureList = new List<string>();
        CultureInfo[] cultures = CultureInfo.GetCultures(CultureTypes.SpecificCultures);
        RegionInfo region;

        public Form2()
        {
            InitializeComponent();
            comboboxcountry.MaxDropDownItems = 10;
            comboboxcountry.IntegralHeight = false;
           
            


        }

        private void labelssn_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            // Get the selected date from the DateTimePicker
            DateTime selectedDate = date_of_birth.Value;

            // Calculate the difference between the selected date and today's date
            TimeSpan difference = DateTime.Now - selectedDate;

            // Check if the difference is greater than or equal to 18 years
            if (difference.TotalDays >= (365.25 * 18))
            {

                try
                {
                    if (con.State != ConnectionState.Open)
                    {
                        con.Open();
                    }

                    int Currentage = DateTime.Now.Year - date_of_birth.Value.Year;
                    string query = "INSERT INTO Client (E_ID, SSN, Name, Age, City, Street, Nationality, Phone_Number, License_Number, Email) VALUES (@E_ID, @SSN, @Name, @Age, @City, @Street, @Nationality, @Phone_Number, @License_Number, @Email)";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@E_ID", frmReg.EmployeeID);
                    cmd.Parameters.AddWithValue("@SSN", int.Parse(txtssn.Text));
                    cmd.Parameters.AddWithValue("@Name", txtname.Text);
                    cmd.Parameters.AddWithValue("@Age", Currentage);
                    cmd.Parameters.AddWithValue("@City", txtcity.Text);
                    cmd.Parameters.AddWithValue("@Street", txtstr.Text);
                    cmd.Parameters.AddWithValue("@Nationality", comboboxcountry.Text);
                    cmd.Parameters.AddWithValue("@Phone_Number", int.Parse(txtphone.Text));
                    cmd.Parameters.AddWithValue("@License_Number", txtlnumber.Text);
                    cmd.Parameters.AddWithValue("@Email", txtemail.Text);

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Client Added Successfully");

                    if (con.State == ConnectionState.Open)
                    {
                        con.Close();
                    }
                }
                catch (Exception msg)
                {

                    MessageBox.Show("Please Enter Correct Information");
                }
            }
            else
            {
                MessageBox.Show("Client is Younger Than 18 Years Old");
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {
            foreach (CultureInfo culture in cultures)
            {
                region = new RegionInfo(culture.LCID);
                if(!(cultureList.Contains(region.EnglishName)))
                {
                    cultureList.Add(region.EnglishName);
                    comboboxcountry.Items.Add(region.EnglishName);
                }
            }
        }

        private void btnload_Click(object sender, EventArgs e)
        {
            string query = "select * from Client";
            SqlDataAdapter adapter = new SqlDataAdapter(query, con);
            DataTable dt= new DataTable();
            adapter.Fill(dt);
            
            
        }

        private void dvClient_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void txtssn_TextChanged(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void comboboxcountry_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            txtcity.Text= string.Empty;
            txtemail.Text= string.Empty;   
            txtlnumber.Text= string.Empty;  
            txtname.Text= string.Empty;
            txtphone.Text= string.Empty;
            txtssn.Text= string.Empty;
            txtstr.Text= string.Empty;
            
        }
    }
}
