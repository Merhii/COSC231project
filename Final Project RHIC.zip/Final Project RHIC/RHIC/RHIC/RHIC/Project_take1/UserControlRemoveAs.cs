﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_take1
{
    public partial class UserControlRemoveAs : UserControl
    {
        public UserControlRemoveAs()
        {
            InitializeComponent();

            SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["myDB"].ToString());
            string query = "select * from Accident_Specialist";
            SqlDataAdapter adapter = new SqlDataAdapter(query, con);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            dataGridLoadEmp.DataSource = dt;
        }

        private void txt_Empsearch_TextChanged(object sender, EventArgs e)
        {

            SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["myDB"].ToString());
            string query = "SELECT * FROM Accident_Specialist WHERE Name LIKE @Name";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@Name", txt_Empsearch.Text + '%');

            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            dataGridLoadEmp.DataSource = dt;
        }

        private void btn_LoadEmp_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["myDB"].ToString());
            string query = "select * from Accident_Specialist";
            SqlDataAdapter adapter = new SqlDataAdapter(query, con);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            dataGridLoadEmp.DataSource = dt;
        }

        private void UserControlRemoveAs_Load(object sender, EventArgs e)
        {

        }
    }
}
