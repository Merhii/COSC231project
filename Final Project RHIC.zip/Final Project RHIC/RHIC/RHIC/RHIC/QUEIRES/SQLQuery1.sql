﻿CREATE TABLE Employee (
E_ID INT,
Email NVARCHAR(55),
Password NVARCHAR(8),
PRIMARY KEY (E_ID)
);


CREATE TABLE Vehicle_Insurance (
Model NVARCHAR(30),
Price REAL,
PRIMARY KEY (Modle,Price)
);


CREATE TABLE Vehicle_Policy (
Policy_Number INT,
C_ID int,
Model NVARCHAR(30),
Price REAL,
Coverage REAL,
Start_Date Date ,
Exppiry_Date DATE,
Active BIT,
PRIMARY KEY (Policy_Number)
);


Alter table Vehicle_Policy
Add constraint Policy_Insurance_Model
Foreign key (Model) References Vehicle_Insurance(Model);

Alter table Vehicle_Policy
Add constraint Policy_Insurance_Price
Foreign key (Price) References Vehicle_Insurance(Price);

Alter table Vehicle_Policy
Add constraint Client_Policy_CID
Foreign key (C_ID) References Client(C_ID);


CREATE TABLE Vehicle (
Plate_Number NVARCHAR(15),
Car_Number INT,
Model_Year INT,
Brand NVARCHAR(15),
Color NVARCHAR(15),
C_ID int,
PRIMARY KEY (Plate_Number, Car_Number));


Alter table Vehicle
Add constraint Client_Vehicle_CID
Foreign key (C_ID) References Client(C_ID);


CREATE TABLE Payment_Details (
P_ID INT,
C_ID int,
Payment_Date Date,
Amount REAL,
Payment_Method NVARCHAR(25),
Card_Number INT,
Card_Type NVARCHAR(25),
Card_Provider NVARCHAR(25),
Bank_Name NVARCHAR(25),
Account_Number INT,
Check_Number INT,
PRIMARY KEY (P_ID));


Alter table Payment_Details
Add constraint Client_Payment_CID
Foreign key (C_ID) References Client(C_ID);



CREATE TABLE Client (
C_ID INT ,
E_ID int,
SSN INT,
Name NVARCHAR (25),
Age INT,
City NVARCHAR(25),
Street NVARCHAR (25),
Nationality NVARCHAR(25),
Phone_Number INT,
License_Number INT,
Email NVARCHAR(35) ,
PRIMARY KEY (C_ID));


Alter table Client
Add constraint Employee_Client_ID
Foreign key (E_ID) References Employee(E_ID);


CREATE TABLE Accident (
A_ID INT,
C_ID int,
D_ID int,
AS_ID int,
Plate_Number NVARCHAR(15),
Car_Number INT,
Policy_Number INT,
Place NVARCHAR (25),
Date_Of_Acc DATE,
Approval BIT,
Expenses REAL,
PRIMARY KEY (A_ID));


Alter table Accident
Add constraint Vehicle_Accident_PlateNumber
Foreign key (Plate_Number) References Vehicle(Plate_Number);

Alter table Accident
Add constraint Client_Accident_CID
Foreign key (C_ID) References Client(C_ID);

Alter table Accident
Add constraint VehiclePolicy_Accident_PolicyNum
Foreign key (Policy_Number) References Vehicle_Policy(Policy_Number);

Alter table Accident
Add constraint Vehicle_Accident_CarNumber
Foreign key (Car_Number) References Vehicle(Car_Number);

Alter table Accident
Add constraint Doctor_Accident_DID
Foreign key (D_ID) References Doctor(D_ID);

Alter table Accident
Add constraint Accident_Specialist_Accident_CID
Foreign key (AS_ID) References Accident_Specialist(AS_ID);


CREATE TABLE Accident_Specialist (
AS_ID INT,
Name NVARCHAR (25),
Phone_Number INT,
Email NVARCHAR(25),
Address NVARCHAR(25),
PRIMARY KEY (AS_ID)
)




