﻿CREATE TABLE Employee (
E_ID INT,
Email NVARCHAR(55),
Password NVARCHAR(8),
PRIMARY KEY (E_ID)
);
INSERT INTO Employee VALUES (
1,'lea@gmail.com','lol123');
INSERT INTO Employee VALUES (
2,'karim@gmail.com','lol333');
