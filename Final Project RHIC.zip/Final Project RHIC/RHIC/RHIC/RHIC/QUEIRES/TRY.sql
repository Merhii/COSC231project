﻿CREATE TABLE Client (
C_ID INT ,
E_ID int,
SSN INT,
Name NVARCHAR (25),
Age INT,
City NVARCHAR(25),
Street NVARCHAR (25),
Nationality NVARCHAR(25),
Phone_Number INT,
License_Number NVARCHAR(25),
Email NVARCHAR(35) ,
PRIMARY KEY (C_ID));